import type { DynamoDBRecord, KinesisStreamRecord, SQSRecord } from 'aws-lambda';
import type { EventSourceDataClassTypes, PartialItemFailureResponse } from './types.js';
/**
 * Enum of supported event types for the utility
 */
declare const EventType: {
    readonly SQS: "SQS";
    readonly KinesisDataStreams: "KinesisDataStreams";
    readonly DynamoDBStreams: "DynamoDBStreams";
};
/**
 * Enum of supported schema vendors for the utility
 */
declare const SchemaVendor: {
    readonly Zod: "zod";
};
/**
 * Default response for the partial batch processor
 */
declare const DEFAULT_RESPONSE: PartialItemFailureResponse;
/**
 * Mapping of event types to their respective data classes
 */
declare const DATA_CLASS_MAPPING: {
    SQS: (record: EventSourceDataClassTypes) => SQSRecord;
    KinesisDataStreams: (record: EventSourceDataClassTypes) => KinesisStreamRecord;
    DynamoDBStreams: (record: EventSourceDataClassTypes) => DynamoDBRecord;
};
export { EventType, SchemaVendor, DEFAULT_RESPONSE, DATA_CLASS_MAPPING };
//# sourceMappingURL=constants.d.ts.map