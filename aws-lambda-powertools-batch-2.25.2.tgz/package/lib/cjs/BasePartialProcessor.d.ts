import type { BaseRecord, BatchProcessingOptions, EventSourceDataClassTypes, FailureResponse, SuccessResponse } from './types.js';
/**
 * Abstract class for batch processors.
 *
 * This class provides a common interface for processing records in a batch.
 *
 * Batch processors implementing this class should provide implementations for
 * a number of abstract methods that are specific to the type of processor or the
 * type of records being processed.
 *
 * The class comes with a few helper methods and hooks that can be used to prepare
 * the processor before processing records, clean up after processing records, and
 * handle records that succeed or fail processing.
 */
declare abstract class BasePartialProcessor {
    #private;
    /**
     * List of errors that occurred during processing
     */
    errors: Error[];
    /**
     * List of records that failed processing
     */
    failureMessages: EventSourceDataClassTypes[];
    /**
     * Record handler provided by customers to process records
     */
    handler: CallableFunction;
    /**
     * Options to be used during processing (optional)
     */
    options?: BatchProcessingOptions;
    /**
     * List of records to be processed
     */
    records: BaseRecord[];
    /**
     * List of records that were processed successfully
     */
    successMessages: EventSourceDataClassTypes[];
    constructor();
    /**
     * Clean or resets the processor instance after completing a batch
     *
     * This method should be called after processing a full batch to reset the processor.
     *
     * You can use this as a hook to run any cleanup logic after processing the records.
     */
    abstract clean(): void;
    /**
     * Method to handle a record that failed processing
     *
     * This method should be called when a record fails processing so that
     * the processor can keep track of the error and the record that failed.
     *
     * @param record - Record that failed processing
     * @param error - Error that was thrown
     */
    failureHandler(record: EventSourceDataClassTypes, error: Error): FailureResponse;
    /**
     * Prepare class instance before processing
     *
     * This method should be called before processing the records
     *
     * You can use this as a hook to run any setup logic before processing the records.
     */
    abstract prepare(): void;
    /**
     * Process all records with an asynchronous handler
     *
     * Once called, the processor will create an array of promises to process each record
     * and wait for all of them to settle before returning the results.
     *
     * Before and after processing, the processor will call the prepare and clean methods respectively.
     */
    process(): Promise<(SuccessResponse | FailureResponse)[]>;
    /**
     * Process a record with an asynchronous handler
     *
     * An implementation of this method is required for asynchronous processors.
     *
     * When implementing this method, you should at least call the successHandler method
     * when a record succeeds processing and the failureHandler method when a record
     * fails processing.
     *
     * This is to ensure that the processor keeps track of the results and the records
     * that succeeded and failed processing.
     *
     * @param record - Record to be processed
     */
    abstract processRecord(record: BaseRecord): Promise<SuccessResponse | FailureResponse>;
    /**
     * Process a record with a synchronous handler
     *
     * An implementation of this method is required for synchronous processors.
     *
     * When implementing this method, you should at least call the successHandler method
     * when a record succeeds processing and the failureHandler method when a record
     * fails processing.
     *
     * This is to ensure that the processor keeps track of the results and the records
     * that succeeded and failed processing.
     *
     * @param record - Record to be processed
     */
    abstract processRecordSync(record: BaseRecord): SuccessResponse | FailureResponse;
    /**
     * Orchestrate the processing of a batch of records synchronously
     * and sequentially.
     *
     * The method is responsible for calling the prepare method before
     * processing the records and the clean method after processing the records.
     *
     * In the middle, the method will iterate over the records and call the
     * processRecordSync method for each record.
     *
     * @returns List of processed records
     */
    processSync(): (SuccessResponse | FailureResponse)[];
    /**
     * Set up the processor with the records and the handler
     *
     * This method should be called before processing the records to
     * bind the records and the handler for a specific invocation to
     * the processor.
     *
     * We use a separate method to do this rather than the constructor
     * to allow for reusing the processor instance across multiple invocations
     * by instantiating the processor outside of the Lambda function handler.
     *
     * @param records - Array of records to be processed
     * @param handler - CallableFunction to process each record from the batch
     * @param options - Options to be used during processing (optional)
     */
    register(records: BaseRecord[], handler: CallableFunction, options?: BatchProcessingOptions): this;
    /**
     * Method to handle a record that succeeded processing
     *
     * This method should be called when a record succeeds processing so that
     * the processor can keep track of the result and the record that succeeded.
     *
     * @param record - Record that succeeded processing
     * @param result - Result from record handler
     */
    successHandler(record: EventSourceDataClassTypes, result: unknown): SuccessResponse;
}
export { BasePartialProcessor };
//# sourceMappingURL=BasePartialProcessor.d.ts.map