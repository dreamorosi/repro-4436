import type { StandardSchemaV1 } from '@standard-schema/spec';
import type { DynamoDBRecord, KinesisStreamRecord, SQSRecord } from 'aws-lambda';
import { BasePartialProcessor } from './BasePartialProcessor.js';
import { EventType } from './constants.js';
import type { BasePartialBatchProcessorConfig, EventSourceDataClassTypes, PartialItemFailureResponse, PartialItemFailures } from './types.js';
/**
 * Base abstract class for processing batch records with partial failure handling
 *
 * This class extends the {@link BasePartialProcessor} class and adds additional
 * functionality to handle batch processing. Specifically, it provides methods
 * to collect failed records and build the partial failure response.
 */
declare abstract class BasePartialBatchProcessor extends BasePartialProcessor {
    /**
     * Mapping of event types to their respective failure collectors
     *
     * Each service expects a different format for partial failure reporting,
     * this mapping ensures that the correct format is used for each event type.
     */
    COLLECTOR_MAPPING: {
        SQS: () => PartialItemFailures[];
        KinesisDataStreams: () => PartialItemFailures[];
        DynamoDBStreams: () => PartialItemFailures[];
    };
    /**
     * Response to be returned after processing
     */
    batchResponse: PartialItemFailureResponse;
    /**
     * Type of event that the processor is handling
     */
    eventType: keyof typeof EventType;
    /**
     * The schema of the body of the event record for parsing
     */
    protected schema?: StandardSchemaV1;
    /**
     * Initializes base batch processing class
     *
     * @param eventType The type of event to process (SQS, Kinesis, DynamoDB)
     */
    constructor(eventType: keyof typeof EventType, config?: BasePartialBatchProcessorConfig);
    /**
     * Clean up logic to be run after processing a batch
     *
     * If the entire batch failed this method will throw a {@link FullBatchFailureError | `FullBatchFailureError`} with the list of
     * errors that occurred during processing, unless the `throwOnFullBatchFailure` option is set to `false`.
     *
     * Otherwise, it will build the partial failure response based on the event type.
     */
    clean(): void;
    /**
     * Collect the identifiers of failed items for a DynamoDB stream
     *
     * The failures are collected based on the sequence number of the record
     * and formatted as a list of objects with the key `itemIdentifier` as
     * expected by the service.
     */
    collectDynamoDBFailures(): PartialItemFailures[];
    /**
     * Collect identifiers of failed items for a Kinesis batch
     *
     * The failures are collected based on the sequence number of the record
     * and formatted as a list of objects with the key `itemIdentifier` as
     * expected by the service.
     */
    collectKinesisFailures(): PartialItemFailures[];
    /**
     * Collect identifiers of failed items for an SQS batch
     *
     * The failures are collected based on the message ID of the record
     * and formatted as a list of objects with the key `itemIdentifier` as
     * expected by the service.
     */
    collectSqsFailures(): PartialItemFailures[];
    /**
     * Determine if the entire batch failed
     *
     * If the number of errors is equal to the number of records, then the
     * entire batch failed and this method will return `true`.
     */
    entireBatchFailed(): boolean;
    /**
     * Collect identifiers for failed batch items
     *
     * The method will call the appropriate collector based on the event type
     * and return the list of failed items.
     */
    getMessagesToReport(): PartialItemFailures[];
    /**
     * Determine if there are any failed records to report
     *
     * If there are no failed records, then the batch was successful
     * and this method will return `false`.
     */
    hasMessagesToReport(): boolean;
    /**
     * Set up the processor with the initial state ready for processing
     */
    prepare(): void;
    /**
     * Get the response from the batch processing
     */
    response(): PartialItemFailureResponse;
    /**
     * Forward a record to the appropriate batch type
     *
     * Based on the event type that the processor was initialized with, this method
     * will cast the record to the appropriate batch type handler.
     *
     * @param record The record to be processed
     * @param eventType The type of event to process
     */
    toBatchType(record: EventSourceDataClassTypes, eventType: keyof typeof EventType): SQSRecord | KinesisStreamRecord | DynamoDBRecord;
}
export { BasePartialBatchProcessor };
//# sourceMappingURL=BasePartialBatchProcessor.d.ts.map