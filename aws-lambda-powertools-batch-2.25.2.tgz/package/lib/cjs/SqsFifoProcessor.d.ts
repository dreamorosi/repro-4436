import type { BatchProcessingOptions, EventSourceDataClassTypes } from './types.js';
/**
 * Class representing a processor for SQS FIFO messages.
 * This class provides utilities for handling message groups, including tracking failed groups,
 * determining whether to short-circuit processing, and skipping groups based on processing options.
 */
declare class SqsFifoProcessor {
    #private;
    constructor();
    /**
     * Adds the specified group ID to the set of failed group IDs.
     *
     * @param group - The group ID to be added to the set of failed group IDs.
     */
    addToFailedGroup(group: string): void;
    /**
     * Prepares the processor for a new batch of messages.
     */
    prepare(): void;
    /**
     * Sets the current group ID for the message being processed.
     *
     * @param group - The group ID of the current message being processed.
     */
    setCurrentGroup(group?: string): void;
    /**
     * Determines whether the current group should be short-circuited.
     *
     * If we have any failed messages, we should then short circuit the process and
     * fail remaining messages unless `skipGroupOnError` is true
     *
     * @param failureMessages - The list of failure messages.
     * @param options - The options for the batch processing.
     */
    shouldShortCircuit(failureMessages: EventSourceDataClassTypes[], options?: BatchProcessingOptions): boolean;
    /**
     * Determines whether the current group should be skipped.
     *
     * If `skipGroupOnError` is true and the current group has previously failed,
     * then we should skip processing the current group.
     *
     * @param options - The options for the batch processing.
     */
    shouldSkipCurrentGroup(options?: BatchProcessingOptions): boolean;
    /**
     * Handles failure for current group
     * Adds the current group ID to the set of failed group IDs if `skipGroupOnError` is true.
     *
     * @param options - The options for the batch processing.
     */
    processFailureForCurrentGroup(options?: BatchProcessingOptions): void;
}
export { SqsFifoProcessor };
//# sourceMappingURL=SqsFifoProcessor.d.ts.map