/**
 * Base error thrown by the Batch Processing utility
 */
declare class BatchProcessingError extends Error {
    constructor(message: string);
}
/**
 * Error thrown by the Batch Processing utility when all batch records failed to be processed
 */
declare class FullBatchFailureError extends BatchProcessingError {
    recordErrors: Error[];
    constructor(childErrors: Error[]);
}
/**
 * Error thrown by the Batch Processing utility when a SQS FIFO queue is short-circuited.
 * This happens when a record fails processing and the remaining records are not processed
 * to avoid out-of-order delivery.
 */
declare class SqsFifoShortCircuitError extends BatchProcessingError {
    constructor();
}
/**
 * Error thrown by the Batch Processing utility when a previous record from
 * SQS FIFO queue message group fails processing.
 */
declare class SqsFifoMessageGroupShortCircuitError extends BatchProcessingError {
    constructor();
}
/**
 * Error thrown by the Batch Processing utility when a partial processor receives an unexpected
 * batch type.
 */
declare class UnexpectedBatchTypeError extends BatchProcessingError {
    constructor();
}
export { BatchProcessingError, FullBatchFailureError, SqsFifoShortCircuitError, SqsFifoMessageGroupShortCircuitError, UnexpectedBatchTypeError, };
//# sourceMappingURL=errors.d.ts.map