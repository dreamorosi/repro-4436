/**
 * Zod schema for Lambda Function URL follows the API Gateway HTTP APIs Payload Format Version 2.0.
 *
 * Keys related to API Gateway features not available in Function URL use a sentinel value (e.g.`routeKey`, `stage`).
 *
 * @example
 * ```json
 * {
 *  "version": "2.0",
 *  "routeKey": "$default",
 *  "rawPath": "/",
 *  "rawQueryString": "",
 *  "headers": {
 *    "sec-fetch-mode": "navigate",
 *    "x-amzn-tls-version": "TLSv1.2",
 *    "sec-fetch-site": "cross-site",
 *    "accept-language": "pt-BR,pt;q=0.9",
 *    "x-forwarded-proto": "https",
 *    "x-forwarded-port": "443",
 *    "x-forwarded-for": "123.123.123.123",
 *    "sec-fetch-user": "?1",
 *    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng;q=0.8,application/signed-exchange;v=b3;q=0.9",
 *    "x-amzn-tls-cipher-suite": "ECDHE-RSA-AES128-GCM-SHA256",
 *    "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"102\", \"Google Chrome\";v=\"102\"",
 *    "sec-ch-ua-mobile": "?0",
 *    "x-amzn-trace-id": "Root=1-62ecd163-5f302e550dcde3b12402207d",
 *    "sec-ch-ua-platform": "\"Linux\"",
 *    "host": "<url-id>.lambda-url.us-east-1.on.aws",
 *    "upgrade-insecure-requests": "1",
 *    "cache-control": "max-age=0",
 *    "accept-encoding": "gzip, deflate, br",
 *    "sec-fetch-dest": "document",
 *    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36"
 *  },
 *  "requestContext": {
 *    "accountId": "anonymous",
 *    "apiId": "<url-id>",
 *    "domainName": "<url-id>.lambda-url.us-east-1.on.aws",
 *    "domainPrefix": "<url-id>",
 *    "http": {
 *      "method": "GET",
 *      "path": "/",
 *      "protocol": "HTTP/1.1",
 *      "sourceIp": "123.123.123.123",
 *      "userAgent": "agent"
 *    },
 *    "requestId": "id",
 *    "routeKey": "$default",
 *    "stage": "$default",
 *    "time": "05/Aug/2022:08:14:39 +0000",
 *    "timeEpoch": 1659687279885
 *  },
 *  "isBase64Encoded": false
 * }
 * ```
 *
 * @see {@link LambdaFunctionUrlEvent | `LambdaFunctionUrlEvent`}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/urls-invocation.html#urls-payloads}
 */
declare const LambdaFunctionUrlSchema: import("zod").ZodObject<{
    version: import("zod").ZodString;
    routeKey: import("zod").ZodString;
    rawPath: import("zod").ZodString;
    rawQueryString: import("zod").ZodString;
    cookies: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString>>;
    headers: import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodString>;
    queryStringParameters: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodString>>;
    requestContext: import("zod").ZodObject<{
        accountId: import("zod").ZodString;
        apiId: import("zod").ZodString;
        authorizer: import("zod").ZodOptional<import("zod").ZodObject<{
            jwt: import("zod").ZodOptional<import("zod").ZodObject<{
                claims: import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>;
                scopes: import("zod").ZodNullable<import("zod").ZodArray<import("zod").ZodString>>;
            }, import("zod/v4/core").$strip>>;
            iam: import("zod").ZodOptional<import("zod").ZodObject<{
                accessKey: import("zod").ZodOptional<import("zod").ZodString>;
                accountId: import("zod").ZodOptional<import("zod").ZodString>;
                callerId: import("zod").ZodOptional<import("zod").ZodString>;
                principalOrgId: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodString>>;
                userArn: import("zod").ZodOptional<import("zod").ZodString>;
                userId: import("zod").ZodOptional<import("zod").ZodString>;
                cognitoIdentity: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodObject<{
                    amr: import("zod").ZodArray<import("zod").ZodString>;
                    identityId: import("zod").ZodString;
                    identityPoolId: import("zod").ZodString;
                }, import("zod/v4/core").$strip>>>;
            }, import("zod/v4/core").$strip>>;
            lambda: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodAny>>>;
        }, import("zod/v4/core").$strip>>;
        authentication: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodObject<{
            clientCert: import("zod").ZodOptional<import("zod").ZodObject<{
                clientCertPem: import("zod").ZodString;
                subjectDN: import("zod").ZodString;
                issuerDN: import("zod").ZodString;
                serialNumber: import("zod").ZodString;
                validity: import("zod").ZodObject<{
                    notBefore: import("zod").ZodString;
                    notAfter: import("zod").ZodString;
                }, import("zod/v4/core").$strip>;
            }, import("zod/v4/core").$strip>>;
        }, import("zod/v4/core").$strip>>>;
        domainName: import("zod").ZodString;
        domainPrefix: import("zod").ZodString;
        http: import("zod").ZodObject<{
            method: import("zod").ZodEnum<{
                GET: "GET";
                POST: "POST";
                PUT: "PUT";
                PATCH: "PATCH";
                DELETE: "DELETE";
                HEAD: "HEAD";
                OPTIONS: "OPTIONS";
            }>;
            path: import("zod").ZodString;
            protocol: import("zod").ZodString;
            sourceIp: import("zod").ZodUnion<readonly [import("zod").ZodIPv4, import("zod").ZodIPv6]>;
            userAgent: import("zod").ZodString;
        }, import("zod/v4/core").$strip>;
        requestId: import("zod").ZodString;
        routeKey: import("zod").ZodString;
        stage: import("zod").ZodString;
        time: import("zod").ZodString;
        timeEpoch: import("zod").ZodNumber;
    }, import("zod/v4/core").$strip>;
    body: import("zod").ZodOptional<import("zod").ZodString>;
    pathParameters: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodString>>>;
    isBase64Encoded: import("zod").ZodBoolean;
    stageVariables: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodString>>>;
}, import("zod/v4/core").$strip>;
export { LambdaFunctionUrlSchema };
//# sourceMappingURL=lambda.d.ts.map