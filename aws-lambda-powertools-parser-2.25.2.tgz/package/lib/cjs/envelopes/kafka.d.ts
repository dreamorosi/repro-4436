import { type ZodType, z } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * Kafka event envelope to extract data within body key
 * The record's body parameter is a string, though it can also be a JSON encoded string.
 * Regardless of its type it'll be parsed into a BaseModel object.
 *
 * Note: Records will be parsed the same way so if model is str,
 * all items in the list will be parsed as str and not as JSON (and vice versa)
 */
export declare const KafkaEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "array";
    parse<T>(data: unknown, schema: ZodType<T>): z.infer<ZodType<T>>[];
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, z.infer<ZodType<T>>[]>;
};
//# sourceMappingURL=kafka.d.ts.map