import { type ZodType } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * CloudWatch Envelope to extract messages from the `awslogs.data.logEvents` key.
 */
export declare const CloudWatchEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "array";
    parse<T>(data: unknown, schema: ZodType<T>): T[];
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T[]>;
};
//# sourceMappingURL=cloudwatch.d.ts.map