/**
 * This is a discriminator to differentiate whether an envelope returns an array or an object
 * @hidden
 */
declare const envelopeDiscriminator: unique symbol;
export { envelopeDiscriminator };
//# sourceMappingURL=envelope.d.ts.map