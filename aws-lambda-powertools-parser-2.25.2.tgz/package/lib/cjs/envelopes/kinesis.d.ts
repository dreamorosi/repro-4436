import { type ZodType } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * Kinesis Data Stream Envelope to extract array of Records
 *
 * The record's data parameter is a base64 encoded string which is parsed into a bytes array,
 * though it can also be a JSON encoded string.
 * Regardless of its type it'll be parsed into a BaseModel object.
 *
 * Note: Records will be parsed the same way so if model is str,
 * all items in the list will be parsed as str and not as JSON (and vice versa)
 */
export declare const KinesisEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "array";
    parse<T>(data: unknown, schema: ZodType<T>): T[];
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T[]>;
};
//# sourceMappingURL=kinesis.d.ts.map