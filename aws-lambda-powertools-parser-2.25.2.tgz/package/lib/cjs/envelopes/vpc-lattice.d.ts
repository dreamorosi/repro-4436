import type { ZodType, z } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * Amazon VPC Lattice envelope to extract data within body key
 */
export declare const VpcLatticeEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "object";
    parse<T>(data: unknown, schema: ZodType<T>): z.infer<ZodType<T>>;
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, z.infer<ZodType<T>>>;
};
//# sourceMappingURL=vpc-lattice.d.ts.map