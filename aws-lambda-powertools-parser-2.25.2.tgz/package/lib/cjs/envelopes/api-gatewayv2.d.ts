import type { ZodType } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * API Gateway V2 envelope to extract data within body key
 */
export declare const ApiGatewayV2Envelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "object";
    parse<T>(data: unknown, schema: ZodType<T>): T;
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T>;
};
//# sourceMappingURL=api-gatewayv2.d.ts.map