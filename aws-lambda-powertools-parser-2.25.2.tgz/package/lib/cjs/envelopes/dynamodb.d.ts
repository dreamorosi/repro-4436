import { type ZodType } from 'zod';
import type { DynamoDBStreamEnvelopeResponse } from '../types/envelope.js';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * DynamoDB Stream Envelope to extract data within NewImage/OldImage
 *
 * Note: Values are the parsed models. Images' values can also be None, and
 * length of the list is the record's amount in the original event.
 */
export declare const DynamoDBStreamEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "array";
    parse<T>(data: unknown, schema: ZodType<T>): DynamoDBStreamEnvelopeResponse<T>[];
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, DynamoDBStreamEnvelopeResponse<T>[]>;
};
//# sourceMappingURL=dynamodb.d.ts.map