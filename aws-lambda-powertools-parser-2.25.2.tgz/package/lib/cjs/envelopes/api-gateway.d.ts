import type { ZodType } from 'zod';
import type { ParsedResult } from '../types/parser.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * API Gateway envelope to extract data within body key
 */
export declare const ApiGatewayEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "object";
    parse<T>(data: unknown, schema: ZodType<T>): T;
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T>;
};
//# sourceMappingURL=api-gateway.d.ts.map