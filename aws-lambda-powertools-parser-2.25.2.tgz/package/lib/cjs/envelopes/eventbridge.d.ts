import type { ZodType } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * Envelope for EventBridge schema that extracts and parses data from the `detail` key.
 */
export declare const EventBridgeEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "object";
    parse<T>(data: unknown, schema: ZodType<T>): T;
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T>;
};
//# sourceMappingURL=eventbridge.d.ts.map