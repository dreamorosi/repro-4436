import { type ZodType } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * SQS Envelope to extract array of Records
 *
 * The record's `body` parameter is a string and needs to be parsed against the provided schema.
 *
 * If you know that the `body` is a JSON string, you can use `JSONStringified` to parse it,
 * for example:
 *
 * ```ts
 * import { JSONStringified } from '@aws-lambda-powertools/helpers';
 * import { SqsEnvelope } from '@aws-lambda-powertools/parser/envelopes/sqs';
 *
 * const schema = z.object({
 *   name: z.string(),
 * });
 *
 * const parsed = SqsEnvelope.parse(event, JSONStringified(schema));
 * ```
 */
declare const SqsEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "array";
    parse<T>(data: unknown, schema: ZodType<T>): T[];
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T[]>;
};
export { SqsEnvelope };
//# sourceMappingURL=sqs.d.ts.map