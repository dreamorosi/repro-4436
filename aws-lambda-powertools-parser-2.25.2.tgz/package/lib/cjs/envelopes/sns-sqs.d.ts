import { type ZodType } from 'zod';
import type { ParsedResult } from '../types/index.js';
import { envelopeDiscriminator } from './envelope.js';
/**
 * SNS plus SQS Envelope to extract array of Records
 *
 * Published messages from SNS to SQS has a slightly different payload structure
 * than regular SNS messages, and when sent to SQS, they are stringified into the
 * `body` field of each SQS record.
 *
 * To parse the `Message` field of the SNS notification, we need to:
 * 1. Parse SQS schema with incoming data
 * 2. `JSON.parse()` the SNS payload and parse against SNS Notification schema
 * 3. Finally, parse the payload against the provided schema
 */
export declare const SnsSqsEnvelope: {
    /**
     * This is a discriminator to differentiate whether an envelope returns an array or an object
     * @hidden
     */
    [envelopeDiscriminator]: "array";
    parse<T>(data: unknown, schema: ZodType<T>): T[];
    safeParse<T>(data: unknown, schema: ZodType<T>): ParsedResult<unknown, T[]>;
};
//# sourceMappingURL=sns-sqs.d.ts.map