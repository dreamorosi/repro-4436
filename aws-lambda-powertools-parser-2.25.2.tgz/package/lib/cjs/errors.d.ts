/**
 * Custom parsing error that wraps any erros thrown during schema or envelope parsing.
 * The cause of the error is included in the message, if possible.
 */
declare class ParseError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
export { ParseError };
//# sourceMappingURL=errors.d.ts.map