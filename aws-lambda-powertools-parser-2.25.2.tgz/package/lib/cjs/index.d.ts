export { ParseError } from './errors.js';
export { parse } from './parser.js';
export { parser } from './parserDecorator.js';
//# sourceMappingURL=index.d.ts.map