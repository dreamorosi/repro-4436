import type { AttributeValue } from '@aws-sdk/client-dynamodb';
import { type ZodType, z } from 'zod';
/**
 * A helper function to unmarshall DynamoDB stream events and validate them against a schema.
 *
 * @example
 * ```typescript
 * const mySchema = z.object({
 *   id: z.string(),
 *   name: z.string(),
 * });
 * const eventSchema = DynamoDBStreamSchema.extend({
 *   Records: z.array(
 *     DynamoDBStreamRecord.extend({
 *       dynamodb: z.object({
 *         NewImage: DynamoDBMarshalled(mySchema).optional(),
 *       }),
 *     })
 *   ),
 * });
 * type eventSchema = z.infer<typeof extendedSchema>;
 * ```
 * For example, if you have a DynamoDB stream event like the following:
 *
 * ```json
 * {
 *   "Records": [
 *     {
 *       "dynamodb": {
 *         "NewImage": {
 *           "id": {
 *             "S": "12345"
 *           },
 *           "name": {
 *             "S": "John Doe"
 *           }
 *         }
 *       }
 *     }
 *   ]
 * }
 * ```
 * Resulting in:
 *
 * ```json
 * {
 *   "Records": [
 *     {
 *       "dynamodb": {
 *         "NewImage": {
 *           "id": "12345",
 *           "name": "John Doe"
 *         }
 *       }
 *     }
 *   ]
 * }
 * ```
 *
 * @param schema - The schema to validate the JSON string against
 */
declare const DynamoDBMarshalled: <T>(schema: ZodType<T>) => z.ZodPipe<z.ZodPipe<z.ZodUnion<readonly [z.ZodCustom<AttributeValue, AttributeValue>, z.ZodRecord<z.ZodString, z.ZodCustom<AttributeValue, AttributeValue>>]>, z.ZodTransform<unknown, AttributeValue | Record<string, AttributeValue>>>, ZodType<T, unknown, z.core.$ZodTypeInternals<T, unknown>>>;
export { DynamoDBMarshalled };
//# sourceMappingURL=dynamodb.d.ts.map