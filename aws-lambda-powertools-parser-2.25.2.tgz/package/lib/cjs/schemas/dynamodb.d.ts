import { z } from 'zod';
declare const DynamoDBStreamChangeRecordBase: z.ZodObject<{
    ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
    Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
    NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    SequenceNumber: z.ZodString;
    SizeBytes: z.ZodNumber;
    StreamViewType: z.ZodEnum<{
        NEW_IMAGE: "NEW_IMAGE";
        OLD_IMAGE: "OLD_IMAGE";
        NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
        KEYS_ONLY: "KEYS_ONLY";
    }>;
}, z.core.$strip>;
declare const DynamoDBStreamToKinesisChangeRecord: z.ZodObject<{
    ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
    Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
    NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    SizeBytes: z.ZodNumber;
}, z.core.$strip>;
declare const DynamoDBStreamChangeRecord: z.ZodPipe<z.ZodObject<{
    ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
    Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
    NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    SequenceNumber: z.ZodString;
    SizeBytes: z.ZodNumber;
    StreamViewType: z.ZodEnum<{
        NEW_IMAGE: "NEW_IMAGE";
        OLD_IMAGE: "OLD_IMAGE";
        NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
        KEYS_ONLY: "KEYS_ONLY";
    }>;
}, z.core.$strip>, z.ZodTransform<{
    Keys: Record<string, Record<string, any>>;
    SizeBytes: number;
    ApproximateCreationDateTime?: number | undefined;
    NewImage?: Record<string, any> | undefined;
    OldImage?: Record<string, any> | undefined;
}, {
    Keys: Record<string, Record<string, any>>;
    SequenceNumber: string;
    SizeBytes: number;
    StreamViewType: "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY";
    ApproximateCreationDateTime?: number | undefined;
    NewImage?: Record<string, any> | undefined;
    OldImage?: Record<string, any> | undefined;
}>>;
declare const UserIdentity: z.ZodObject<{
    type: z.ZodEnum<{
        Service: "Service";
    }>;
    principalId: z.ZodLiteral<"dynamodb.amazonaws.com">;
}, z.core.$strip>;
declare const DynamoDBStreamRecord: z.ZodObject<{
    eventID: z.ZodString;
    eventName: z.ZodEnum<{
        INSERT: "INSERT";
        MODIFY: "MODIFY";
        REMOVE: "REMOVE";
    }>;
    eventVersion: z.ZodString;
    eventSource: z.ZodLiteral<"aws:dynamodb">;
    awsRegion: z.ZodString;
    eventSourceARN: z.ZodString;
    dynamodb: z.ZodPipe<z.ZodObject<{
        ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
        Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
        NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        SequenceNumber: z.ZodString;
        SizeBytes: z.ZodNumber;
        StreamViewType: z.ZodEnum<{
            NEW_IMAGE: "NEW_IMAGE";
            OLD_IMAGE: "OLD_IMAGE";
            NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
            KEYS_ONLY: "KEYS_ONLY";
        }>;
    }, z.core.$strip>, z.ZodTransform<{
        Keys: Record<string, Record<string, any>>;
        SizeBytes: number;
        ApproximateCreationDateTime?: number | undefined;
        NewImage?: Record<string, any> | undefined;
        OldImage?: Record<string, any> | undefined;
    }, {
        Keys: Record<string, Record<string, any>>;
        SequenceNumber: string;
        SizeBytes: number;
        StreamViewType: "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY";
        ApproximateCreationDateTime?: number | undefined;
        NewImage?: Record<string, any> | undefined;
        OldImage?: Record<string, any> | undefined;
    }>>;
    userIdentity: z.ZodOptional<z.ZodObject<{
        type: z.ZodEnum<{
            Service: "Service";
        }>;
        principalId: z.ZodLiteral<"dynamodb.amazonaws.com">;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Zod schema for Amazon DynamoDB Stream event sent to an Amazon Kinesis Stream.
 *
 * This schema is best used in conjunction with the {@link KinesisEnvelope | `KinesisEnvelope`} when
 * you want to work with the DynamoDB stream event coming from an Amazon Kinesis Stream.
 *
 * By default, we unmarshall the `dynamodb.Keys`, `dynamodb.NewImage`, and `dynamodb.OldImage` fields
 * for you.
 *
 * If you want to extend the schema and provide your own Zod schema for any of these fields,
 * you can use the {@link DynamoDBMarshalled | `DynamoDBMarshalled`} helper. In that case, we won't unmarshall the other fields.
 *
 * To extend the schema, you can use the {@link DynamoDBStreamToKinesisRecord | `DynamoDBStreamToKinesisRecord`} child schema and the {@link DynamoDBMarshalled | `DynamoDBMarshalled`}
 * helper together.
 *
 * @example
 * ```ts
 * import {
 *   DynamoDBStreamToKinesisRecord,
 *   DynamoDBStreamToKinesisChangeRecord,
 * } from '@aws-lambda-powertools/parser/schemas/dynamodb';
 * import { KinesisEnvelope } from '@aws-lambda-powertools/parser/envelopes/dynamodb';
 * import { DynamoDBMarshalled } from '@aws-lambda-powertools/parser/helpers/dynamodb';
 *
 * const CustomSchema = DynamoDBStreamToKinesisRecord.extend({
 *   dynamodb: DynamoDBStreamToKinesisChangeRecord.extend({
 *    NewImage: DynamoDBMarshalled(
 *      z.object({
 *        id: z.string(),
 *        attribute: z.number(),
 *        stuff: z.array(z.string()),
 *      })
 *    ),
 *    // Add the lines below only if you want these keys to be unmarshalled
 *    Keys: DynamoDBMarshalled(z.unknown()),
 *    OldImage: DynamoDBMarshalled(z.unknown()),
 *  }),
 * });
 *
 * type CustomEvent = z.infer<typeof CustomSchema>;
 * ```
 */
declare const DynamoDBStreamToKinesisRecord: z.ZodObject<{
    eventSource: z.ZodLiteral<"aws:dynamodb">;
    eventID: z.ZodString;
    eventName: z.ZodEnum<{
        INSERT: "INSERT";
        MODIFY: "MODIFY";
        REMOVE: "REMOVE";
    }>;
    awsRegion: z.ZodString;
    dynamodb: z.ZodPipe<z.ZodObject<{
        ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
        Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
        NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        SizeBytes: z.ZodNumber;
    }, z.core.$strip>, z.ZodTransform<{
        Keys: Record<string, Record<string, any>>;
        SizeBytes: number;
        ApproximateCreationDateTime?: number | undefined;
        NewImage?: Record<string, any> | undefined;
        OldImage?: Record<string, any> | undefined;
    }, {
        Keys: Record<string, Record<string, any>>;
        SizeBytes: number;
        ApproximateCreationDateTime?: number | undefined;
        NewImage?: Record<string, any> | undefined;
        OldImage?: Record<string, any> | undefined;
    }>>;
    userIdentity: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        type: z.ZodEnum<{
            Service: "Service";
        }>;
        principalId: z.ZodLiteral<"dynamodb.amazonaws.com">;
    }, z.core.$strip>>>;
    recordFormat: z.ZodLiteral<"application/json">;
    tableName: z.ZodString;
}, z.core.$strip>;
/**
 * Zod schema for Amazon DynamoDB Stream event.
 *
 * @example
 * ```json
 * {
 *   "Records":[{
 *     "eventID":"1",
 *     "eventName":"INSERT",
 *     "eventVersion":"1.0",
 *     "eventSource":"aws:dynamodb",
 *     "awsRegion":"us-east-1",
 *     "dynamodb":{
 *       "Keys":{
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "NewImage":{
 *         "Message":{
 *           "S":"New item!"
 *         },
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "SequenceNumber":"111",
 *       "SizeBytes":26,
 *       "StreamViewType":"NEW_AND_OLD_IMAGES"
 *     },
 *     "eventSourceARN":"stream-ARN"
 *   },
 *   {
 *     "eventID":"2",
 *     "eventName":"MODIFY",
 *     "eventVersion":"1.0",
 *     "eventSource":"aws:dynamodb",
 *     "awsRegion":"us-east-1",
 *     "dynamodb":{
 *       "Keys":{
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "NewImage":{
 *         "Message":{
 *           "S":"This item has changed"
 *         },
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "OldImage":{
 *         "Message":{
 *           "S":"New item!"
 *         },
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "SequenceNumber":"222",
 *       "SizeBytes":59,
 *       "StreamViewType":"NEW_AND_OLD_IMAGES"
 *     },
 *     "eventSourceARN":"stream-ARN"
 *   },
 *   {
 *     "eventID":"3",
 *     "eventName":"REMOVE",
 *     "eventVersion":"1.0",
 *     "eventSource":"aws:dynamodb",
 *     "awsRegion":"us-east-1",
 *     "dynamodb":{
 *       "Keys":{
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "OldImage":{
 *         "Message":{
 *           "S":"This item has changed"
 *         },
 *         "Id":{
 *           "N":"101"
 *         }
 *       },
 *       "SequenceNumber":"333",
 *       "SizeBytes":38,
 *       "StreamViewType":"NEW_AND_OLD_IMAGES"
 *     },
 *     "eventSourceARN":"stream-ARN"
 *   }],
 *   "window": {
 *     "start": "2020-07-30T17:00:00Z",
 *     "end": "2020-07-30T17:05:00Z"
 *   },
 *   "state": {
 *     "1": "state1"
 *   },
 *   "shardId": "shard123456789",
 *   "eventSourceARN": "stream-ARN",
 *   "isFinalInvokeForWindow": false,
 *   "isWindowTerminatedEarly": false
 * }
 * ```
 *
 * @see {@link DynamoDBStreamEvent | DynamoDBStreamEvent}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/with-ddb.html}
 */
declare const DynamoDBStreamSchema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        eventID: z.ZodString;
        eventName: z.ZodEnum<{
            INSERT: "INSERT";
            MODIFY: "MODIFY";
            REMOVE: "REMOVE";
        }>;
        eventVersion: z.ZodString;
        eventSource: z.ZodLiteral<"aws:dynamodb">;
        awsRegion: z.ZodString;
        eventSourceARN: z.ZodString;
        dynamodb: z.ZodPipe<z.ZodObject<{
            ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
            Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
            NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
            OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
            SequenceNumber: z.ZodString;
            SizeBytes: z.ZodNumber;
            StreamViewType: z.ZodEnum<{
                NEW_IMAGE: "NEW_IMAGE";
                OLD_IMAGE: "OLD_IMAGE";
                NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
                KEYS_ONLY: "KEYS_ONLY";
            }>;
        }, z.core.$strip>, z.ZodTransform<{
            Keys: Record<string, Record<string, any>>;
            SizeBytes: number;
            ApproximateCreationDateTime?: number | undefined;
            NewImage?: Record<string, any> | undefined;
            OldImage?: Record<string, any> | undefined;
        }, {
            Keys: Record<string, Record<string, any>>;
            SequenceNumber: string;
            SizeBytes: number;
            StreamViewType: "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY";
            ApproximateCreationDateTime?: number | undefined;
            NewImage?: Record<string, any> | undefined;
            OldImage?: Record<string, any> | undefined;
        }>>;
        userIdentity: z.ZodOptional<z.ZodObject<{
            type: z.ZodEnum<{
                Service: "Service";
            }>;
            principalId: z.ZodLiteral<"dynamodb.amazonaws.com">;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    window: z.ZodOptional<z.ZodObject<{
        start: z.ZodISODateTime;
        end: z.ZodISODateTime;
    }, z.core.$strip>>;
    state: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    shardId: z.ZodOptional<z.ZodString>;
    eventSourceARN: z.ZodOptional<z.ZodString>;
    isFinalInvokeForWindow: z.ZodOptional<z.ZodBoolean>;
    isWindowTerminatedEarly: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export { DynamoDBStreamToKinesisRecord, DynamoDBStreamToKinesisChangeRecord, DynamoDBStreamSchema, DynamoDBStreamRecord, DynamoDBStreamChangeRecord, DynamoDBStreamChangeRecordBase, UserIdentity, };
//# sourceMappingURL=dynamodb.d.ts.map