import { z } from 'zod';
import { AppSyncCognitoIdentity, AppSyncIamIdentity, AppSyncOidcIdentity } from './appsync-shared.js';
/**
 * A zod schema for the AppSync Events `identity` object when using an AWS Lambda Authorizer.
 */
declare const AppSyncLambdaAuthIdentity: z.ZodObject<{
    handlerContext: z.ZodRecord<z.ZodString, z.ZodUnknown>;
}, z.core.$strip>;
/**
 * A zod schema for AppSync Events request object.
 *
 * This schema is used when extending subscribe and publish events.
 */
declare const AppSyncEventsRequestSchema: z.ZodObject<{
    headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    domainName: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * A zod schema for AppSync Events info object.
 *
 * This schema is used when extending subscribe and publish events.
 */
declare const AppSyncEventsInfoSchema: z.ZodObject<{
    channel: z.ZodObject<{
        path: z.ZodString;
        segments: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    channelNamespace: z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>;
    operation: z.ZodUnion<readonly [z.ZodLiteral<"PUBLISH">, z.ZodLiteral<"SUBSCRIBE">]>;
}, z.core.$strip>;
/**
 * A zod schema for AppSync Events base events.
 *
 * This schema is used as a base for both publish and subscribe events.
 */
declare const AppSyncEventsBaseSchema: z.ZodObject<{
    identity: z.ZodUnion<readonly [z.ZodNull, z.ZodObject<{
        sub: z.ZodString;
        issuer: z.ZodString;
        username: z.ZodString;
        claims: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        sourceIp: z.ZodArray<z.ZodIPv4>;
        defaultAuthStrategy: z.ZodNullable<z.ZodString>;
        groups: z.ZodNullable<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        accountId: z.ZodString;
        cognitoIdentityPoolId: z.ZodNullable<z.ZodString>;
        cognitoIdentityId: z.ZodNullable<z.ZodString>;
        sourceIp: z.ZodArray<z.ZodString>;
        username: z.ZodString;
        userArn: z.ZodString;
        cognitoIdentityAuthType: z.ZodNullable<z.ZodString>;
        cognitoIdentityAuthProvider: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        handlerContext: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strip>, z.ZodObject<{
        claims: z.ZodAny;
        issuer: z.ZodString;
        sub: z.ZodString;
    }, z.core.$strip>]>;
    result: z.ZodNull;
    request: z.ZodObject<{
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        domainName: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    info: z.ZodObject<{
        channel: z.ZodObject<{
            path: z.ZodString;
            segments: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        channelNamespace: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        operation: z.ZodUnion<readonly [z.ZodLiteral<"PUBLISH">, z.ZodLiteral<"SUBSCRIBE">]>;
    }, z.core.$strip>;
    error: z.ZodNull;
    prev: z.ZodNull;
    stash: z.ZodObject<{}, z.core.$strip>;
    outErrors: z.ZodArray<z.ZodUnknown>;
    events: z.ZodNull;
}, z.core.$strip>;
/**
 * A zod schema for AppSync Events publish events.
 *
 * @example
 * ```json
 * {
 *   "identity": null,
 *   "result": null,
 *   "request": {
 *     "headers": {
 *       "header1": "value1",
 *     },
 *     "domainName": "example.com"
 *   },
 *   "info": {
 *     "channel": {
 *       "path": "/default/foo",
 *       "segments": ["default", "foo"]
 *     },
 *     "channelNamespace": {
 *       "name": "default"
 *     },
 *     "operation": "PUBLISH"
 *   },
 *   "error": null,
 *   "prev": null,
 *   "stash": {},
 *   "outErrors": [],
 *   "events": [
 *     {
 *       "payload": {
 *         "key": "value"
 *       },
 *       "id": "12345"
 *     },
 *     {
 *       "payload": {
 *         "key2": "value2"
 *       },
 *       "id": "67890"
 *     }
 *   ]
 * }
 * ```
 *
 * @see {@link AppSyncEventsPublishEvent | `AppSyncEventsPublishEvent`}
 */
declare const AppSyncEventsPublishSchema: z.ZodObject<{
    identity: z.ZodUnion<readonly [z.ZodNull, z.ZodObject<{
        sub: z.ZodString;
        issuer: z.ZodString;
        username: z.ZodString;
        claims: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        sourceIp: z.ZodArray<z.ZodIPv4>;
        defaultAuthStrategy: z.ZodNullable<z.ZodString>;
        groups: z.ZodNullable<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        accountId: z.ZodString;
        cognitoIdentityPoolId: z.ZodNullable<z.ZodString>;
        cognitoIdentityId: z.ZodNullable<z.ZodString>;
        sourceIp: z.ZodArray<z.ZodString>;
        username: z.ZodString;
        userArn: z.ZodString;
        cognitoIdentityAuthType: z.ZodNullable<z.ZodString>;
        cognitoIdentityAuthProvider: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        handlerContext: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strip>, z.ZodObject<{
        claims: z.ZodAny;
        issuer: z.ZodString;
        sub: z.ZodString;
    }, z.core.$strip>]>;
    result: z.ZodNull;
    request: z.ZodObject<{
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        domainName: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    error: z.ZodNull;
    prev: z.ZodNull;
    stash: z.ZodObject<{}, z.core.$strip>;
    outErrors: z.ZodArray<z.ZodUnknown>;
    info: z.ZodObject<{
        channel: z.ZodObject<{
            path: z.ZodString;
            segments: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        channelNamespace: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        operation: z.ZodLiteral<"PUBLISH">;
    }, z.core.$strip>;
    events: z.ZodArray<z.ZodObject<{
        payload: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        id: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * A zod schema for AppSync Events subscribe events.
 *
 * @example
 * ```json
 * {
 *   "identity": null,
 *   "result": null,
 *   "request": {
 *     "headers": {
 *       "header1": "value1",
 *     },
 *     "domainName": "example.com"
 *   },
 *   "info": {
 *     "channel": {
 *       "path": "/default/foo",
 *       "segments": ["default", "foo"]
 *     },
 *     "channelNamespace": {
 *       "name": "default"
 *     },
 *     "operation": "SUBSCRIBE"
 *   },
 *   "error": null,
 *   "prev": null,
 *   "stash": {},
 *   "outErrors": [],
 *   "events": null,
 * }
 * ```
 *
 * @see {@link AppSyncEventsSubscribeEvent | `AppSyncEventsSubscribeEvent`}
 */
declare const AppSyncEventsSubscribeSchema: z.ZodObject<{
    identity: z.ZodUnion<readonly [z.ZodNull, z.ZodObject<{
        sub: z.ZodString;
        issuer: z.ZodString;
        username: z.ZodString;
        claims: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        sourceIp: z.ZodArray<z.ZodIPv4>;
        defaultAuthStrategy: z.ZodNullable<z.ZodString>;
        groups: z.ZodNullable<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        accountId: z.ZodString;
        cognitoIdentityPoolId: z.ZodNullable<z.ZodString>;
        cognitoIdentityId: z.ZodNullable<z.ZodString>;
        sourceIp: z.ZodArray<z.ZodString>;
        username: z.ZodString;
        userArn: z.ZodString;
        cognitoIdentityAuthType: z.ZodNullable<z.ZodString>;
        cognitoIdentityAuthProvider: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        handlerContext: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strip>, z.ZodObject<{
        claims: z.ZodAny;
        issuer: z.ZodString;
        sub: z.ZodString;
    }, z.core.$strip>]>;
    result: z.ZodNull;
    request: z.ZodObject<{
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        domainName: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    error: z.ZodNull;
    prev: z.ZodNull;
    stash: z.ZodObject<{}, z.core.$strip>;
    outErrors: z.ZodArray<z.ZodUnknown>;
    info: z.ZodObject<{
        channel: z.ZodObject<{
            path: z.ZodString;
            segments: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        channelNamespace: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        operation: z.ZodLiteral<"SUBSCRIBE">;
    }, z.core.$strip>;
    events: z.ZodNull;
}, z.core.$strip>;
export { AppSyncEventsBaseSchema, AppSyncCognitoIdentity, AppSyncIamIdentity, AppSyncLambdaAuthIdentity, AppSyncOidcIdentity, AppSyncEventsRequestSchema, AppSyncEventsInfoSchema, AppSyncEventsPublishSchema, AppSyncEventsSubscribeSchema, };
//# sourceMappingURL=appsync-events.d.ts.map