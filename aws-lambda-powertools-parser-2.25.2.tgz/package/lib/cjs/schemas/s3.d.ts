import { z } from 'zod';
/**
 * Zod schema for S3 -> EventBridge -> Lambda event notification.
 *
 * @example
 * ```json
 * {
 *   "version": "0",
 *   "id": "f5f1e65c-dc3a-93ca-6c1e-b1647eac7963",
 *   "detail-type": "Object Created",
 *   "source": "aws.s3",
 *   "account": "123456789012",
 *   "time": "2023-03-08T17:50:14Z",
 *   "region": "eu-west-1",
 *   "resources": [
 *     "arn:aws:s3:::example-bucket"
 *   ],
 *   "detail": {
 *     "version": "0",
 *     "bucket": {
 *       "name": "example-bucket"
 *     },
 *     "object": {
 *       "key": "IMG_m7fzo3.jpg",
 *       "size": 184662,
 *       "etag": "4e68adba0abe2dc8653dc3354e14c01d",
 *       "sequencer": "006408CAD69598B05E"
 *     },
 *     "request-id": "57H08PA84AB1JZW0",
 *     "requester": "123456789012",
 *     "source-ip-address": "34.252.34.74",
 *     "reason": "PutObject"
 *   }
 * }
 * ```
 *
 * @see {@link S3EventNotificationEventBridge | `S3EventNotificationEventBridge` }
 * @see {@link https://docs.aws.amazon.com/AmazonS3/latest/userguide/ev-events.html#ev-events-list}
 */
declare const S3EventNotificationEventBridgeSchema: z.ZodObject<{
    version: z.ZodString;
    id: z.ZodString;
    source: z.ZodString;
    account: z.ZodString;
    time: z.ZodISODateTime;
    region: z.ZodString;
    resources: z.ZodArray<z.ZodString>;
    'detail-type': z.ZodString;
    'replay-name': z.ZodOptional<z.ZodString>;
    detail: z.ZodObject<{
        version: z.ZodString;
        bucket: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        object: z.ZodObject<{
            key: z.ZodString;
            size: z.ZodOptional<z.ZodNumber>;
            etag: z.ZodOptional<z.ZodString>;
            'version-id': z.ZodOptional<z.ZodString>;
            sequencer: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        'request-id': z.ZodString;
        requester: z.ZodString;
        'source-ip-address': z.ZodOptional<z.ZodIPv4>;
        reason: z.ZodOptional<z.ZodString>;
        'deletion-type': z.ZodOptional<z.ZodString>;
        'restore-expiry-time': z.ZodOptional<z.ZodString>;
        'source-storage-class': z.ZodOptional<z.ZodString>;
        'destination-storage-class': z.ZodOptional<z.ZodString>;
        'destination-access-tier': z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * Zod schema for S3 event
 *
 * @example
 * ```json
 * {
 *   "Records": [
 *     {
 *       "eventVersion": "2.1",
 *       "eventSource": "aws:s3",
 *       "awsRegion": "us-east-2",
 *       "eventTime": "2019-09-03T19:37:27.192Z",
 *       "eventName": "ObjectCreated:Put",
 *       "userIdentity": {
 *         "principalId": "AWS:AIDAINPONIXQXHT3IKHL2"
 *       },
 *       "requestParameters": {
 *         "sourceIPAddress": "205.255.255.255"
 *       },
 *       "responseElements": {
 *         "x-amz-request-id": "D82B88E5F771F645",
 *         "x-amz-id-2": "vlR7PnpV2Ce81l0PRw6jlUpck7Jo5ZsQjryTjKlc5aLWGVHPZLj5NeC6qMa0emYBDXOo6QBU0Wo="
 *       },
 *       "s3": {
 *         "s3SchemaVersion": "1.0",
 *         "configurationId": "828aa6fc-f7b5-4305-8584-487c791949c1",
 *         "bucket": {
 *           "name": "lambda-artifacts-deafc19498e3f2df",
 *           "ownerIdentity": {
 *             "principalId": "A3I5XTEXAMAI3E"
 *           },
 *           "arn": "arn:aws:s3:::lambda-artifacts-deafc19498e3f2df"
 *         },
 *         "object": {
 *           "key": "b21b84d653bb07b05b1e6b33684dc11b",
 *           "size": 1305107,
 *           "eTag": "b21b84d653bb07b05b1e6b33684dc11b",
 *           "sequencer": "0C0F6F405D6ED209E1"
 *         }
 *       }
 *     }
 *   ]
 * }
 * ```
 * @see {@link S3Event | `S3Event` }
 * @see {@link https://docs.aws.amazon.com/AmazonS3/latest/userguide/notification-content-structure.html}
 */
declare const S3Schema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        eventVersion: z.ZodString;
        eventSource: z.ZodLiteral<"aws:s3">;
        awsRegion: z.ZodString;
        eventTime: z.ZodISODateTime;
        eventName: z.ZodString;
        userIdentity: z.ZodObject<{
            principalId: z.ZodString;
        }, z.core.$strip>;
        requestParameters: z.ZodObject<{
            sourceIPAddress: z.ZodUnion<readonly [z.ZodIPv4, z.ZodLiteral<"s3.amazonaws.com">]>;
        }, z.core.$strip>;
        responseElements: z.ZodObject<{
            'x-amz-request-id': z.ZodString;
            'x-amz-id-2': z.ZodString;
        }, z.core.$strip>;
        s3: z.ZodObject<{
            s3SchemaVersion: z.ZodString;
            configurationId: z.ZodString;
            object: z.ZodObject<{
                key: z.ZodString;
                size: z.ZodOptional<z.ZodNumber>;
                urlDecodedKey: z.ZodOptional<z.ZodString>;
                eTag: z.ZodOptional<z.ZodString>;
                sequencer: z.ZodOptional<z.ZodString>;
                versionId: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>;
            bucket: z.ZodObject<{
                name: z.ZodString;
                ownerIdentity: z.ZodObject<{
                    principalId: z.ZodString;
                }, z.core.$strip>;
                arn: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>;
        glacierEventData: z.ZodOptional<z.ZodObject<{
            restoreEventData: z.ZodObject<{
                lifecycleRestorationExpiryTime: z.ZodString;
                lifecycleRestoreStorageClass: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Zod schema for S3 -> SQS -> Lambda event notification.
 *
 * Each SQS record’s body field is automatically parsed from a JSON string
 * and then validated as an S3 event.
 *
 * @example
 * ```json
 * {
 *   "Records": [
 *     {
 *       "messageId": "ca3e7a89-c358-40e5-8aa0-5da01403c267",
 *       "receiptHandle": "AQEBE7XoI7IQRLF7SrpiW9W4BanmOWe8UtVDbv6/CEZYKf/OktSNIb4j689tQfR4k44V/LY20lZ5VpxYt2GTYCsSLKTcBalTJaRX9CKu/hVqy/23sSNiKxnP56D+VLSn+hU275+AP1h4pUL0d9gLdRB2haX8xiM+LcGfis5Jl8BBXtoxKRF60O87O9/NvCmmXLeqkJuexfyEZNyed0fFCRXFXSjbmThG0OIQgcrGI8glBRGPA8htns58VtXFsSaPYNoqP3p5n6+ewKKVLD0lfm+0DlnLKRa+mjvFBaSer9KK1ff+Aq6zJ6HynPwADj+aF70Hwimc2zImYe51SLEF/E2csYlMNZYI/2qXW0m9R7wJ/XDTV4g2+h+BMTxsKnJQ6NQd",
 *       "body": "{\"Records\":[{\"eventVersion\":\"2.1\",\"eventSource\":\"aws:s3\",\"awsRegion\":\"us-east-1\",\"eventTime\":\"2023-04-12T20:43:38.021Z\",\"eventName\":\"ObjectCreated:Put\",\"userIdentity\":{\"principalId\":\"A1YQ72UWCM96UF\"},\"requestParameters\":{\"sourceIPAddress\":\"93.108.161.96\"},\"responseElements\":{\"x-amz-request-id\":\"YMSSR8BZJ2Y99K6P\",\"x-amz-id-2\":\"6ASrUfj5xpn859fIq+6FXflOex/SKl/rjfiMd7wRzMg/zkHKR22PDpnh7KD3uq//cuOTbdX4DInN5eIs+cR0dY1z2Mc5NDP/\"},\"s3\":{\"s3SchemaVersion\":\"1.0\",\"configurationId\":\"SNS\",\"bucket\":{\"name\":\"xxx\",\"ownerIdentity\":{\"principalId\":\"A1YQ72UWCM96UF\"},\"arn\":\"arn:aws:s3:::xxx\"},\"object\":{\"key\":\"test.pdf\",\"size\":104681,\"eTag\":\"2e3ad1e983318bbd8e73b080e2997980\",\"versionId\":\"yd3d4HaWOT2zguDLvIQLU6ptDTwKBnQV\",\"sequencer\":\"00643717F9F8B85354\"}}}]}",
 *       "attributes": {
 *         "ApproximateReceiveCount": "1",
 *         "SentTimestamp": "1681332219270",
 *         "SenderId": "AIDAJHIPRHEMV73VRJEBU",
 *         "ApproximateFirstReceiveTimestamp": "1681332239270"
 *       },
 *       "messageAttributes": {
 *       },
 *       "md5OfBody": "16f4460f4477d8d693a5abe94fdbbd73",
 *       "eventSource": "aws:sqs",
 *       "eventSourceARN": "arn:aws:sqs:us-east-1:123456789012:SQS",
 *       "awsRegion": "us-east-1"
 *     }
 *   ]
 * }
 * ```
 *
 * @see {@link S3SqsEventNotification | `S3SqsEventNotification` }
 */
declare const S3SqsEventNotificationSchema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        messageId: z.ZodString;
        receiptHandle: z.ZodString;
        attributes: z.ZodObject<{
            ApproximateReceiveCount: z.ZodString;
            ApproximateFirstReceiveTimestamp: z.ZodString;
            MessageDeduplicationId: z.ZodOptional<z.ZodString>;
            MessageGroupId: z.ZodOptional<z.ZodString>;
            SenderId: z.ZodString;
            SentTimestamp: z.ZodString;
            SequenceNumber: z.ZodOptional<z.ZodString>;
            AWSTraceHeader: z.ZodOptional<z.ZodString>;
            DeadLetterQueueSourceArn: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        messageAttributes: z.ZodRecord<z.ZodString, z.ZodObject<{
            stringValue: z.ZodOptional<z.ZodString>;
            binaryValue: z.ZodOptional<z.ZodString>;
            stringListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
            binaryListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
            dataType: z.ZodUnion<readonly [z.ZodLiteral<"String">, z.ZodLiteral<"Number">, z.ZodLiteral<"Binary">, z.ZodString]>;
        }, z.core.$strip>>;
        md5OfBody: z.ZodString;
        md5OfMessageAttributes: z.ZodOptional<z.ZodString>;
        eventSource: z.ZodLiteral<"aws:sqs">;
        eventSourceARN: z.ZodString;
        awsRegion: z.ZodString;
        body: z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<any, string>>, z.ZodObject<{
            Records: z.ZodArray<z.ZodObject<{
                eventVersion: z.ZodString;
                eventSource: z.ZodLiteral<"aws:s3">;
                awsRegion: z.ZodString;
                eventTime: z.ZodISODateTime;
                eventName: z.ZodString;
                userIdentity: z.ZodObject<{
                    principalId: z.ZodString;
                }, z.core.$strip>;
                requestParameters: z.ZodObject<{
                    sourceIPAddress: z.ZodUnion<readonly [z.ZodIPv4, z.ZodLiteral<"s3.amazonaws.com">]>;
                }, z.core.$strip>;
                responseElements: z.ZodObject<{
                    'x-amz-request-id': z.ZodString;
                    'x-amz-id-2': z.ZodString;
                }, z.core.$strip>;
                s3: z.ZodObject<{
                    s3SchemaVersion: z.ZodString;
                    configurationId: z.ZodString;
                    object: z.ZodObject<{
                        key: z.ZodString;
                        size: z.ZodOptional<z.ZodNumber>;
                        urlDecodedKey: z.ZodOptional<z.ZodString>;
                        eTag: z.ZodOptional<z.ZodString>;
                        sequencer: z.ZodOptional<z.ZodString>;
                        versionId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strip>;
                    bucket: z.ZodObject<{
                        name: z.ZodString;
                        ownerIdentity: z.ZodObject<{
                            principalId: z.ZodString;
                        }, z.core.$strip>;
                        arn: z.ZodString;
                    }, z.core.$strip>;
                }, z.core.$strip>;
                glacierEventData: z.ZodOptional<z.ZodObject<{
                    restoreEventData: z.ZodObject<{
                        lifecycleRestorationExpiryTime: z.ZodString;
                        lifecycleRestoreStorageClass: z.ZodString;
                    }, z.core.$strip>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Zod schema for S3 IAM Access Point Lambda event notification.
 *
 * @example
 * ```json
 * {
 *     "xAmzRequestId": "1a5ed718-5f53-471d-b6fe-5cf62d88d02a",
 *     "getObjectContext": {
 *         "inputS3Url": "https://myap-123412341234.s3-accesspoint.us-east-1.amazonaws.com/s3.txt?X-Amz-Security-Token=...",
 *         "outputRoute": "io-iad-cell001",
 *         "outputToken": "..."
 *     },
 *     "configuration": {
 *         "accessPointArn": "arn:aws:s3-object-lambda:us-east-1:123412341234:accesspoint/myolap",
 *         "supportingAccessPointArn": "arn:aws:s3:us-east-1:123412341234:accesspoint/myap",
 *         "payload": "test"
 *     },
 *     "userRequest": {
 *         "url": "/s3.txt",
 *         "headers": {
 *             "Host": "myolap-123412341234.s3-object-lambda.us-east-1.amazonaws.com",
 *             "Accept-Encoding": "identity",
 *             "X-Amz-Content-SHA256": "e3b0c44297fc1c149afbf4c8995fb92427ae41e4649b934ca495991b7852b855"
 *         }
 *     },
 *     "userIdentity": {
 *         "type": "IAMUser",
 *         "principalId": "...",
 *         "arn": "arn:aws:iam::123412341234:user/myuser",
 *         "accountId": "123412341234",
 *         "accessKeyId": "...",
 *         "userName": "Alice"
 *     },
 *     "protocolVersion": "1.00"
 * }
 * ```
 *
 * @see {@link S3ObjectLambdaEvent | `S3ObjectLambdaEvent` }
 * @see {@link https://docs.aws.amazon.com/AmazonS3/latest/userguide/olap-event-context.html}
 */
declare const S3ObjectLambdaEventSchema: z.ZodObject<{
    xAmzRequestId: z.ZodString;
    getObjectContext: z.ZodObject<{
        inputS3Url: z.ZodString;
        outputRoute: z.ZodString;
        outputToken: z.ZodString;
    }, z.core.$strip>;
    configuration: z.ZodObject<{
        accessPointArn: z.ZodString;
        supportingAccessPointArn: z.ZodString;
        payload: z.ZodUnion<readonly [z.ZodString, z.ZodObject<{}, z.core.$strip>]>;
    }, z.core.$strip>;
    userRequest: z.ZodObject<{
        url: z.ZodString;
        headers: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strip>;
    userIdentity: z.ZodObject<{
        type: z.ZodString;
        accountId: z.ZodString;
        accessKeyId: z.ZodString;
        userName: z.ZodOptional<z.ZodString>;
        principalId: z.ZodString;
        arn: z.ZodString;
        sessionContext: z.ZodOptional<z.ZodObject<{
            sessionIssuer: z.ZodObject<{
                type: z.ZodString;
                userName: z.ZodOptional<z.ZodString>;
                principalId: z.ZodString;
                arn: z.ZodString;
                accountId: z.ZodString;
            }, z.core.$strip>;
            attributes: z.ZodObject<{
                creationDate: z.ZodString;
                mfaAuthenticated: z.ZodPipe<z.ZodUnion<readonly [z.ZodBoolean, z.ZodLiteral<"true">, z.ZodLiteral<"false">]>, z.ZodTransform<boolean, boolean | "true" | "false">>;
            }, z.core.$strip>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    protocolVersion: z.ZodString;
}, z.core.$strip>;
export { S3Schema, S3EventNotificationEventBridgeSchema, S3SqsEventNotificationSchema, S3ObjectLambdaEventSchema, };
//# sourceMappingURL=s3.d.ts.map