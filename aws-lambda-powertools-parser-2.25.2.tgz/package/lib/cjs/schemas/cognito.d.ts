import { z } from 'zod';
/**
 * Base schema including the common parameters for all Cognito trigger events.
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/cognito-user-pools-working-with-lambda-triggers.html#cognito-user-pools-lambda-trigger-syntax-shared | Amazon Cognito Developer Guide}
 */
declare const CognitoTriggerBaseSchema: z.ZodObject<{
    version: z.ZodString;
    triggerSource: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    request: z.ZodObject<{}, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Pre-Signup trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "PreSignUp_SignUp",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": {
 *       "email": "johndoe@example.com",
 *       "name": "John Doe"
 *     },
 *     "validationData": null,
 *     "clientMetadata": {
 *       "someKey": "someValue"
 *     }
 *   },
 *   "response": {
 *     "autoConfirmUser": false,
 *     "autoVerifyEmail": false,
 *     "autoVerifyPhone": false
 *   }
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-pre-sign-up.html | Amazon Cognito Developer Guide}
 */
declare const PreSignupTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    triggerSource: z.ZodLiteral<"PreSignUp_SignUp">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        validationData: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userNotFound: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>;
    response: z.ZodObject<{
        autoConfirmUser: z.ZodLiteral<false>;
        autoVerifyEmail: z.ZodLiteral<false>;
        autoVerifyPhone: z.ZodLiteral<false>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Post-Confirmation trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "PostConfirmation_ConfirmSignUp",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": {
 *       "email": "user@example.com",
 *       "name": "John Doe"
 *     },
 *     "clientMetadata": {
 *       "customKey": "customValue"
 *     }
 *   },
 *   "response": {}
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-post-confirmation.html | Amazon Cognito Developer Guide}
 */
declare const PostConfirmationTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    triggerSource: z.ZodLiteral<"PostConfirmation_ConfirmSignUp">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Pre-Authentication trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "PreAuthentication_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "request": {
 *     "userAttributes": {
 *       "email": "user@example.com",
 *       "name": "John Doe"
 *     },
 *     "validationData": {
 *       "someKey": "someValue"
 *     },
 *     "userNotFound": false
 *   },
 *   "response": {}
 * }
 * ```
 *
 *  * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-pre-authentication.html | Amazon Cognito Developer Guide}
 */
declare const PreAuthenticationTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    triggerSource: z.ZodLiteral<"PreAuthentication_Authentication">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        validationData: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userNotFound: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Post-Authentication trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "PostAuthentication_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": {
 *       "email": "user@example.com",
 *       "name": "John Doe"
 *     },
 *     "newDeviceUsed": true,
 *     "clientMetadata": {
 *       "customKey": "customValue"
 *     }
 *   },
 *   "response": {}
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-post-authentication.html | Amazon Cognito Developer Guide}
 */
declare const PostAuthenticationTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
    triggerSource: z.ZodLiteral<"PostAuthentication_Authentication">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        newDeviceUsed: z.ZodOptional<z.ZodBoolean>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Pre-Token Generation trigger event group configuration.
 *
 * Use this schema to extend the {@link PreTokenGenerationTriggerRequestSchema} for the `groupConfiguration` property.
 */
declare const PreTokenGenerationTriggerGroupConfigurationSchema: z.ZodObject<{
    groupsToOverride: z.ZodArray<z.ZodString>;
    iamRolesToOverride: z.ZodArray<z.ZodString>;
    preferredRole: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Pre-Token Generation trigger event request.
 *
 * Use this schema to extend the {@link PreTokenGenerationTriggerSchemaV1} and {@link PreTokenGenerationTriggerSchemaV2AndV3} for the `request` property.
 */
declare const PreTokenGenerationTriggerRequestSchema: z.ZodObject<{
    userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
    groupConfiguration: z.ZodObject<{
        groupsToOverride: z.ZodArray<z.ZodString>;
        iamRolesToOverride: z.ZodArray<z.ZodString>;
        preferredRole: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Pre-Token Generation trigger event (version 1).
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "TokenGeneration_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": { "string": "string" },
 *     "groupConfiguration": {
 *       "groupsToOverride": [ "string", "string" ],
 *       "iamRolesToOverride": [ "string", "string" ],
 *       "preferredRole": "string"
 *     },
 *     "clientMetadata": { "string": "string" }
 *   },
 *   "response": {}
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-pre-token-generation.html | Amazon Cognito Developer Guide}
 */
declare const PreTokenGenerationTriggerSchemaV1: z.ZodObject<{
    version: z.ZodString;
    triggerSource: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        groupConfiguration: z.ZodObject<{
            groupsToOverride: z.ZodArray<z.ZodString>;
            iamRolesToOverride: z.ZodArray<z.ZodString>;
            preferredRole: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Pre-Token Generation trigger event (version 2 and 3).
 *
 * @example
 * ```json
 * {
 *   "version": "2",
 *   "triggerSource": "TokenGeneration_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": { "string": "string" },
 *     "groupConfiguration": {
 *       "groupsToOverride": [ "string", "string" ],
 *       "iamRolesToOverride": [ "string", "string" ],
 *       "preferredRole": "string"
 *     },
 *     "scopes": [ "string", "string" ],
 *     "clientMetadata": { "string": "string" }
 *  },
 *  "response": {}
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-pre-token-generation.html | Amazon Cognito Developer Guide}
 */
declare const PreTokenGenerationTriggerSchemaV2AndV3: z.ZodObject<{
    version: z.ZodString;
    triggerSource: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        groupConfiguration: z.ZodObject<{
            groupsToOverride: z.ZodArray<z.ZodString>;
            iamRolesToOverride: z.ZodArray<z.ZodString>;
            preferredRole: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        scopes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Migrate User trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "UserMigration_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "password": "string",
 *     "validationData": { "key": "value" },
 *     "clientMetadata": { "key": "value" }
 *   },
 *   "response": {
 *     "userAttributes": null,
 *     "finalUserStatus": null,
 *     "messageAction": null,
 *     "desiredDeliveryMediums": null,
 *     "forceAliasCreation": null,
 *     "enableSMSMFA": null
 *   }
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-migrate-user.html | Amazon Cognito Developer Guide}
 */
declare const MigrateUserTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    triggerSource: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    userName: z.ZodString;
    request: z.ZodObject<{
        password: z.ZodString;
        validationData: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>;
    response: z.ZodObject<{
        userAttributes: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>;
        finalUserStatus: z.ZodNullable<z.ZodString>;
        messageAction: z.ZodNullable<z.ZodString>;
        desiredDeliveryMediums: z.ZodNullable<z.ZodArray<z.ZodString>>;
        forceAliasCreation: z.ZodNullable<z.ZodBoolean>;
        enableSMSMFA: z.ZodNullable<z.ZodBoolean>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Custom Message trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "CustomMessage_SignUp",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": {
 *       "email": "user@example.com",
 *       "name": "John Doe"
 *     },
 *     "codeParameter": "{####}",
 *     "usernameParameter": "string",
 *     "linkParameter": "string",
 *     "usernameParameter": null
 *   },
 *   "response": {
 *     "smsMessage": null,
 *     "emailMessage": null,
 *     "emailSubject": null,
 *   }
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-custom-message.html | Amazon Cognito Developer Guide}
 */
declare const CustomMessageTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    triggerSource: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        codeParameter: z.ZodString;
        linkParameter: z.ZodNullable<z.ZodString>;
        usernameParameter: z.ZodNullable<z.ZodString>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>;
    response: z.ZodObject<{
        smsMessage: z.ZodNullable<z.ZodString>;
        emailMessage: z.ZodNullable<z.ZodString>;
        emailSubject: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Custom Email Sender trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "CustomEmailSender_SignUp",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "type": "customEmailSenderRequestV1",
 *     "code": "string",
 *     "clientMetadata": { "string": "string" },
 *     "userAttributes": { "string": "string" }
 *   },
 *   "response": {}
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-custom-email-sender.html | Amazon Cognito Developer Guide}
 */
declare const CustomEmailSenderTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
    triggerSource: z.ZodLiteral<"CustomEmailSender_SignUp">;
    request: z.ZodObject<{
        type: z.ZodLiteral<"customEmailSenderRequestV1">;
        code: z.ZodString;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Custom SMS Sender trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "CustomSMSSender_SignUp",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "type": "customSMSSenderRequestV1",
 *     "code": "string",
 *     "clientMetadata": {
 *       "string": "string"
 *     },
 *     "userAttributes": { "string": "string" }
 *   },
 *   "response": {}
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-custom-sms-sender.html | Amazon Cognito Developer Guide}
 */
declare const CustomSMSSenderTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    response: z.ZodObject<{}, z.core.$strip>;
    triggerSource: z.ZodLiteral<"CustomSMSSender_SignUp">;
    request: z.ZodObject<{
        type: z.ZodLiteral<"customSMSSenderRequestV1">;
        code: z.ZodString;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Challenge Result.
 */
declare const ChallengeResultSchema: z.ZodObject<{
    challengeName: z.ZodUnion<readonly [z.ZodLiteral<"CUSTOM_CHALLENGE">, z.ZodLiteral<"SRP_A">, z.ZodLiteral<"PASSWORD_VERIFIER">, z.ZodLiteral<"SMS_MFA">, z.ZodLiteral<"EMAIL_OTP">, z.ZodLiteral<"SOFTWARE_TOKEN_MFA">, z.ZodLiteral<"DEVICE_SRP_AUTH">, z.ZodLiteral<"DEVICE_PASSWORD_VERIFIER">, z.ZodLiteral<"ADMIN_NO_SRP_AUTH">]>;
    challengeResult: z.ZodBoolean;
    challengeMetadata: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Define Auth Challenge trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "DefineAuthChallenge_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": { "email": "user@example.com", "name": "John Doe" },
 *     "session": [
 *       {
 *         "challengeName": "SRP_A",
 *         "challengeResult": true,
 *         "challengeMetadata": "metadata"
 *       }
 *     ],
 *     "clientMetadata": { "key": "value" },
 *     "userNotFound": false
 *   },
 *   "response": {
 *     "challengeName": "PASSWORD_VERIFIER",
 *     "issueTokens": false,
 *     "failAuthentication": false
 *   }
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-define-auth-challenge.html | Amazon Cognito Developer Guide}
 */
declare const DefineAuthChallengeTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    triggerSource: z.ZodLiteral<"DefineAuthChallenge_Authentication">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        session: z.ZodArray<z.ZodObject<{
            challengeName: z.ZodUnion<readonly [z.ZodLiteral<"CUSTOM_CHALLENGE">, z.ZodLiteral<"SRP_A">, z.ZodLiteral<"PASSWORD_VERIFIER">, z.ZodLiteral<"SMS_MFA">, z.ZodLiteral<"EMAIL_OTP">, z.ZodLiteral<"SOFTWARE_TOKEN_MFA">, z.ZodLiteral<"DEVICE_SRP_AUTH">, z.ZodLiteral<"DEVICE_PASSWORD_VERIFIER">, z.ZodLiteral<"ADMIN_NO_SRP_AUTH">]>;
            challengeResult: z.ZodBoolean;
            challengeMetadata: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userNotFound: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>;
    response: z.ZodObject<{
        challengeName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        issueTokens: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        failAuthentication: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Create Auth Challenge trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "CreateAuthChallenge_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": { "email": "user@example.com", "name": "John Doe" },
 *     "challengeName": "CUSTOM_CHALLENGE",
 *     "session": [
 *       { "challengeName": "SRP_A", "challengeResult": true, "challengeMetadata": "metadata" }
 *     ],
 *     "clientMetadata": { "key": "value" },
 *     "userNotFound": false
 *   },
 *   "response": {
 *     "publicChallengeParameters": { "captchaUrl": "url/123.jpg" },
 *     "privateChallengeParameters": { "answer": "5" },
 *     "challengeMetadata": "custom metadata"
 *   }
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-create-auth-challenge.html | Amazon Cognito Developer Guide}
 */
declare const CreateAuthChallengeTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    triggerSource: z.ZodLiteral<"CreateAuthChallenge_Authentication">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        challengeName: z.ZodString;
        session: z.ZodArray<z.ZodObject<{
            challengeName: z.ZodUnion<readonly [z.ZodLiteral<"CUSTOM_CHALLENGE">, z.ZodLiteral<"SRP_A">, z.ZodLiteral<"PASSWORD_VERIFIER">, z.ZodLiteral<"SMS_MFA">, z.ZodLiteral<"EMAIL_OTP">, z.ZodLiteral<"SOFTWARE_TOKEN_MFA">, z.ZodLiteral<"DEVICE_SRP_AUTH">, z.ZodLiteral<"DEVICE_PASSWORD_VERIFIER">, z.ZodLiteral<"ADMIN_NO_SRP_AUTH">]>;
            challengeResult: z.ZodBoolean;
            challengeMetadata: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userNotFound: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>;
    response: z.ZodObject<{
        publicChallengeParameters: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
        privateChallengeParameters: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
        challengeMetadata: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for a Cognito Verify Auth Challenge Response trigger event.
 *
 * @example
 * ```json
 * {
 *   "version": "1",
 *   "triggerSource": "VerifyAuthChallengeResponse_Authentication",
 *   "region": "us-east-1",
 *   "userPoolId": "us-east-1_ABC123",
 *   "userName": "johndoe",
 *   "callerContext": {
 *     "awsSdkVersion": "2.814.0",
 *     "clientId": "client123"
 *   },
 *   "request": {
 *     "userAttributes": { "email": "user@example.com", "name": "John Doe" },
 *     "privateChallengeParameters": { "answer": "expectedAnswer" },
 *     "challengeAnswer": "userAnswer",
 *     "clientMetadata": { "key": "value" },
 *     "userNotFound": false
 *   },
 *   "response": {
 *     "answerCorrect": true
 *   }
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-lambda-verify-auth-challenge-response.html | Amazon Cognito Developer Guide}
 */
declare const VerifyAuthChallengeTriggerSchema: z.ZodObject<{
    version: z.ZodString;
    region: z.ZodString;
    userPoolId: z.ZodString;
    userName: z.ZodOptional<z.ZodString>;
    callerContext: z.ZodObject<{
        awsSdkVersion: z.ZodString;
        clientId: z.ZodString;
    }, z.core.$strip>;
    triggerSource: z.ZodLiteral<"VerifyAuthChallengeResponse_Authentication">;
    request: z.ZodObject<{
        userAttributes: z.ZodRecord<z.ZodString, z.ZodString>;
        privateChallengeParameters: z.ZodRecord<z.ZodString, z.ZodString>;
        challengeAnswer: z.ZodString;
        clientMetadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        userNotFound: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>;
    response: z.ZodObject<{
        answerCorrect: z.ZodBoolean;
    }, z.core.$strip>;
}, z.core.$strip>;
export { CognitoTriggerBaseSchema, PreSignupTriggerSchema, PostConfirmationTriggerSchema, PreAuthenticationTriggerSchema, PostAuthenticationTriggerSchema, MigrateUserTriggerSchema, CustomMessageTriggerSchema, CustomEmailSenderTriggerSchema, CustomSMSSenderTriggerSchema, ChallengeResultSchema, DefineAuthChallengeTriggerSchema, CreateAuthChallengeTriggerSchema, VerifyAuthChallengeTriggerSchema, PreTokenGenerationTriggerSchemaV1, PreTokenGenerationTriggerSchemaV2AndV3, PreTokenGenerationTriggerGroupConfigurationSchema, PreTokenGenerationTriggerRequestSchema, };
//# sourceMappingURL=cognito.d.ts.map