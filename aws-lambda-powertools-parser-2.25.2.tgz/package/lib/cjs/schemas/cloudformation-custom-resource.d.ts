import { z } from 'zod';
/**
 * Zod schema for CloudFormation Custom Resource event with RequestType = 'Create'
 *
 * @example
 * ```json
 * {
 *   "RequestType": "Create",
 *   "ServiceToken": "arn:aws:lambda:us-east-1:xxx:function:xxxx-CrbuiltinfunctionidProvi-2vKAalSppmKe",
 *   "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com/7F%7Cb1f50fdfc25f3b",
 *   "StackId": "arn:aws:cloudformation:us-east-1:xxxx:stack/xxxx/271845b0-f2e8-11ed-90ac-0eeb25b8ae21",
 *   "RequestId": "xxxxx-d2a0-4dfb-ab1f-xxxxxx",
 *   "LogicalResourceId": "xxxxxxxxx",
 *   "ResourceType": "Custom::MyType",
 *   "ResourceProperties": {
 *     "ServiceToken": "arn:aws:lambda:us-east-1:xxxxx:function:xxxxx",
 *     "MyProps": "ss"
 *   }
 * }
 * ```
 * @see {@link CloudFormationCustomResourceCreateEvent | `CloudFormationCustomResourceCreateEvent`}
 * @see {@link https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/crpg-ref-requesttypes-create.html}
 */
declare const CloudFormationCustomResourceCreateSchema: z.ZodObject<{
    RequestType: z.ZodLiteral<"Create">;
    ServiceToken: z.ZodString;
    ResponseURL: z.ZodURL;
    StackId: z.ZodString;
    RequestId: z.ZodString;
    LogicalResourceId: z.ZodString;
    ResourceType: z.ZodString;
    ResourceProperties: z.ZodRecord<z.ZodString, z.ZodAny>;
}, z.core.$strip>;
/**
 * Zod schema for CloudFormation Custom Resource event with RequestType = 'Delete'
 *
 * @example
 * ```json
 * {
 *   "RequestType": "Delete",
 *   "ServiceToken": "arn:aws:lambda:us-east-1:xxx:function:xxxx-CrbuiltinfunctionidProvi-2vKAalSppmKe",
 *   "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com/7F%7Cb1f50fdfc25f3b",
 *   "StackId": "arn:aws:cloudformation:us-east-1:xxxx:stack/xxxx/271845b0-f2e8-11ed-90ac-0eeb25b8ae21",
 *   "RequestId": "xxxxx-d2a0-4dfb-ab1f-xxxxxx",
 *   "LogicalResourceId": "xxxxxxxxx",
 *   "ResourceType": "Custom::MyType",
 *   "ResourceProperties": {
 *     "ServiceToken": "arn:aws:lambda:us-east-1:xxxxx:function:xxxxx",
 *     "MyProps": "ss"
 *   }
 * }
 * ```
 * @see {@link CloudFormationCustomResourceDeleteEvent | `CloudFormationCustomResourceDeleteEvent`}
 * @see {@link https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/crpg-ref-requesttypes-delete.html}
 */
declare const CloudFormationCustomResourceDeleteSchema: z.ZodObject<{
    RequestType: z.ZodLiteral<"Delete">;
    ServiceToken: z.ZodString;
    ResponseURL: z.ZodURL;
    StackId: z.ZodString;
    RequestId: z.ZodString;
    LogicalResourceId: z.ZodString;
    ResourceType: z.ZodString;
    ResourceProperties: z.ZodRecord<z.ZodString, z.ZodAny>;
}, z.core.$strip>;
/**
 * Zod schema for CloudFormation Custom Resource event with RequestType = 'Update'
 *
 * @example
 * ```json
 * {
 *   "RequestType": "Update",
 *   "ServiceToken": "arn:aws:lambda:us-east-1:xxx:function:xxxx-CrbuiltinfunctionidProvi-2vKAalSppmKe",
 *   "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com/7F%7Cb1f50fdfc25f3b",
 *   "StackId": "arn:aws:cloudformation:us-east-1:xxxx:stack/xxxx/271845b0-f2e8-11ed-90ac-0eeb25b8ae21",
 *   "RequestId": "xxxxx-d2a0-4dfb-ab1f-xxxxxx",
 *   "LogicalResourceId": "xxxxxxxxx",
 *   "ResourceType": "Custom::MyType",
 *   "ResourceProperties": {
 *     "ServiceToken": "arn:aws:lambda:us-east-1:xxxxx:function:xxxxx",
 *     "MyProps": "new"
 *   },
 *   "OldResourceProperties": {
 *     "ServiceToken": "arn:aws:lambda:us-east-1:xxxxx:function:xxxxx-xxxx-xxx",
 *     "MyProps": "old"
 *   }
 * }
 * ```
 * @see {@link CloudFormationCustomResourceUpdateEvent | `CloudFormationCustomResourceUpdateEvent`}
 * @see {@link https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/crpg-ref-requesttypes-update.html}
 */
declare const CloudFormationCustomResourceUpdateSchema: z.ZodObject<{
    RequestType: z.ZodLiteral<"Update">;
    OldResourceProperties: z.ZodRecord<z.ZodString, z.ZodAny>;
    ServiceToken: z.ZodString;
    ResponseURL: z.ZodURL;
    StackId: z.ZodString;
    RequestId: z.ZodString;
    LogicalResourceId: z.ZodString;
    ResourceType: z.ZodString;
    ResourceProperties: z.ZodRecord<z.ZodString, z.ZodAny>;
}, z.core.$strip>;
export { CloudFormationCustomResourceCreateSchema, CloudFormationCustomResourceDeleteSchema, CloudFormationCustomResourceUpdateSchema, };
//# sourceMappingURL=cloudformation-custom-resource.d.ts.map