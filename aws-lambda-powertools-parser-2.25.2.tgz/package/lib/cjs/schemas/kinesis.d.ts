import { z } from 'zod';
declare const KinesisDataStreamRecordPayload: z.ZodObject<{
    kinesisSchemaVersion: z.ZodString;
    partitionKey: z.ZodString;
    sequenceNumber: z.ZodString;
    approximateArrivalTimestamp: z.ZodNumber;
    data: z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<any, string>>, z.ZodAny>;
}, z.core.$strip>;
declare const KinesisDataStreamRecord: z.ZodObject<{
    eventSource: z.ZodLiteral<"aws:kinesis">;
    eventVersion: z.ZodString;
    eventID: z.ZodString;
    eventName: z.ZodLiteral<"aws:kinesis:record">;
    awsRegion: z.ZodString;
    invokeIdentityArn: z.ZodString;
    eventSourceARN: z.ZodString;
    kinesis: z.ZodObject<{
        kinesisSchemaVersion: z.ZodString;
        partitionKey: z.ZodString;
        sequenceNumber: z.ZodString;
        approximateArrivalTimestamp: z.ZodNumber;
        data: z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<any, string>>, z.ZodAny>;
    }, z.core.$strip>;
}, z.core.$strip>;
declare const KinesisDynamoDBStreamSchema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        eventSource: z.ZodLiteral<"aws:kinesis">;
        eventVersion: z.ZodString;
        eventID: z.ZodString;
        eventName: z.ZodLiteral<"aws:kinesis:record">;
        awsRegion: z.ZodString;
        invokeIdentityArn: z.ZodString;
        eventSourceARN: z.ZodString;
        kinesis: z.ZodObject<{
            kinesisSchemaVersion: z.ZodString;
            partitionKey: z.ZodString;
            sequenceNumber: z.ZodString;
            approximateArrivalTimestamp: z.ZodNumber;
            data: z.ZodPipe<z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<any, string>>, z.ZodAny>, z.ZodObject<{
                eventSource: z.ZodLiteral<"aws:dynamodb">;
                eventID: z.ZodString;
                eventName: z.ZodEnum<{
                    INSERT: "INSERT";
                    MODIFY: "MODIFY";
                    REMOVE: "REMOVE";
                }>;
                awsRegion: z.ZodString;
                dynamodb: z.ZodPipe<z.ZodObject<{
                    ApproximateCreationDateTime: z.ZodOptional<z.ZodNumber>;
                    Keys: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>;
                    NewImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
                    OldImage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
                    SizeBytes: z.ZodNumber;
                }, z.core.$strip>, z.ZodTransform<{
                    Keys: Record<string, Record<string, any>>;
                    SizeBytes: number;
                    ApproximateCreationDateTime?: number | undefined;
                    NewImage?: Record<string, any> | undefined;
                    OldImage?: Record<string, any> | undefined;
                }, {
                    Keys: Record<string, Record<string, any>>;
                    SizeBytes: number;
                    ApproximateCreationDateTime?: number | undefined;
                    NewImage?: Record<string, any> | undefined;
                    OldImage?: Record<string, any> | undefined;
                }>>;
                userIdentity: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    type: z.ZodEnum<{
                        Service: "Service";
                    }>;
                    principalId: z.ZodLiteral<"dynamodb.amazonaws.com">;
                }, z.core.$strip>>>;
                recordFormat: z.ZodLiteral<"application/json">;
                tableName: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Zod schema for Kinesis Data Stream event
 *
 * @example
 * ```json
 * {
 *   "Records": [
 *     {
 *       "kinesis": {
 *         "kinesisSchemaVersion": "1.0",
 *         "partitionKey": "1",
 *         "sequenceNumber": "49590338271490256608559692538361571095921575989136588898",
 *         "data": "SGVsbG8sIHRoaXMgaXMgYSB0ZXN0Lg==",
 *         "approximateArrivalTimestamp": 1607497475.000
 *       },
 *       "eventSource": "aws:kinesis",
 *       "eventVersion": "1.0",
 *       "eventID": "shardId-000000000006:49590338271490256608559692538361571095921575989136588898",
 *       "eventName": "aws:kinesis:record",
 *       "invokeIdentityArn": "arn:aws:iam::123456789012:role/lambda-kinesis-role",
 *       "awsRegion": "us-east-1",
 *       "eventSourceARN": "arn:aws:kinesis:us-east-1:123456789012:stream/lambda-stream"
 *     }
 *   ],
 *   "window": {
 *     "start": "2020-12-09T07:04:00Z",
 *     "end": "2020-12-09T07:06:00Z"
 *   },
 *   "state": {
 *     "1": 282,
 *     "2": 715
 *   },
 *   "shardId": "shardId-000000000006",
 *   "eventSourceARN": "arn:aws:kinesis:us-east-1:123456789012:stream/lambda-stream",
 *   "isFinalInvokeForWindow": false,
 *   "isWindowTerminatedEarly": false
 * }
 *```
 * @see {@link KinesisDataStreamEvent | `KinesisDataStreamEvent`}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/services-kinesis-windows.html#streams-tumbling-processing}
 *
 */
declare const KinesisDataStreamSchema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        eventSource: z.ZodLiteral<"aws:kinesis">;
        eventVersion: z.ZodString;
        eventID: z.ZodString;
        eventName: z.ZodLiteral<"aws:kinesis:record">;
        awsRegion: z.ZodString;
        invokeIdentityArn: z.ZodString;
        eventSourceARN: z.ZodString;
        kinesis: z.ZodObject<{
            kinesisSchemaVersion: z.ZodString;
            partitionKey: z.ZodString;
            sequenceNumber: z.ZodString;
            approximateArrivalTimestamp: z.ZodNumber;
            data: z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<any, string>>, z.ZodAny>;
        }, z.core.$strip>;
    }, z.core.$strip>>;
    window: z.ZodOptional<z.ZodObject<{
        start: z.ZodISODateTime;
        end: z.ZodISODateTime;
    }, z.core.$strip>>;
    state: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    shardId: z.ZodOptional<z.ZodString>;
    eventSourceARN: z.ZodOptional<z.ZodString>;
    isFinalInvokeForWindow: z.ZodOptional<z.ZodBoolean>;
    isWindowTerminatedEarly: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export { KinesisDataStreamRecord, KinesisDataStreamRecordPayload, KinesisDataStreamSchema, KinesisDynamoDBStreamSchema, };
//# sourceMappingURL=kinesis.d.ts.map