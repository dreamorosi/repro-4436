import { z } from 'zod';
/**
 * Zod schema for AWS Transfer Family events.
 *
 * @example
 * ```json
 * {
 *   "username": "testUser",
 *   "password": "testPass",
 *   "protocol": "SFTP",
 *   "serverId": "s-abcd123456",
 *   "sourceIp": "192.168.0.100"
 * }
 * ```
 *
 * @see {@link TransferFamilyEvent | `TransferFamilyEvent`}
 * @see {@link https://docs.aws.amazon.com/transfer/latest/userguide/custom-lambda-idp.html}
 */
declare const TransferFamilySchema: z.ZodObject<{
    username: z.ZodString;
    password: z.ZodString;
    protocol: z.ZodString;
    serverId: z.ZodString;
    sourceIp: z.ZodIPv4;
}, z.core.$strip>;
export { TransferFamilySchema };
//# sourceMappingURL=transfer-family.d.ts.map