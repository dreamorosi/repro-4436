import { z } from 'zod';
/**
 * Zod schema for a Kafka record from an Kafka event.
 */
declare const KafkaRecordSchema: z.ZodObject<{
    topic: z.ZodString;
    partition: z.ZodNumber;
    offset: z.ZodNumber;
    timestamp: z.ZodNumber;
    timestampType: z.ZodString;
    key: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    value: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    headers: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodPipe<z.ZodArray<z.ZodNumber>, z.ZodTransform<string, number[]>>>>;
}, z.core.$strip>;
/** Zod schema for Kafka event from Self Managed Kafka
 *
 * @example
 * ```json
 * {
 *   "eventSource":"SelfManagedKafka",
 *   "bootstrapServers":"b-2.demo-cluster-1.a1bcde.c1.kafka.us-east-1.amazonaws.com:9092,b-1.demo-cluster-1.a1bcde.c1.kafka.us-east-1.amazonaws.com:9092",
 *   "records":{
 *      "mytopic-0":[
 *         {
 *            "topic":"mytopic",
 *            "partition":0,
 *            "offset":15,
 *            "timestamp":1545084650987,
 *            "timestampType":"CREATE_TIME",
 *            "key":"cmVjb3JkS2V5",
 *            "value":"eyJrZXkiOiJ2YWx1ZSJ9",
 *            "headers":[
 *               {
 *                  "headerKey":[
 *                     104,
 *                     101,
 *                     97,
 *                     100,
 *                     101,
 *                     114,
 *                     86,
 *                     97,
 *                     108,
 *                     117,
 *                     101
 *                  ]
 *               }
 *            ]
 *         }
 *      ]
 *   }
 * }
 * ```
 *
 * @see {@link KafkaSelfManagedEvent | `KafkaSelfManagedEvent`}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/with-kafka.html}
 */
declare const KafkaSelfManagedEventSchema: z.ZodObject<{
    bootstrapServers: z.ZodOptional<z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<string[], string>>>>;
    records: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodObject<{
        topic: z.ZodString;
        partition: z.ZodNumber;
        offset: z.ZodNumber;
        timestamp: z.ZodNumber;
        timestampType: z.ZodString;
        key: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
        value: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
        headers: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodPipe<z.ZodArray<z.ZodNumber>, z.ZodTransform<string, number[]>>>>;
    }, z.core.$strip>>>;
    eventSource: z.ZodLiteral<"SelfManagedKafka">;
}, z.core.$strip>;
/**
 * Zod schema for Kafka event from MSK
 *
 * @example
 * ```json
 * {
 *   "eventSource":"aws:kafka",
 *   "eventSourceArn":"arn:aws:kafka:us-east-1:0123456789019:cluster/SalesCluster/abcd1234-abcd-cafe-abab-9876543210ab-4",
 *   "bootstrapServers":"b-2.demo-cluster-1.a1bcde.c1.kafka.us-east-1.amazonaws.com:9092,b-1.demo-cluster-1.a1bcde.c1.kafka.us-east-1.amazonaws.com:9092",
 *   "records":{
 *      "mytopic-0":[
 *         {
 *            "topic":"mytopic",
 *            "partition":0,
 *            "offset":15,
 *            "timestamp":1545084650987,
 *            "timestampType":"CREATE_TIME",
 *            "key":"cmVjb3JkS2V5",
 *            "value":"eyJrZXkiOiJ2YWx1ZSJ9",
 *            "headers":[
 *               {
 *                  "headerKey":[
 *                     104,
 *                     101,
 *                     97,
 *                     100,
 *                     101,
 *                     114,
 *                     86,
 *                     97,
 *                     108,
 *                     117,
 *                     101
 *                  ]
 *               }
 *            ]
 *         }
 *      ]
 *   }
 * }
 * ```
 *
 * @see {@link KafkaMskEvent | `KafkaMskEvent`}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/with-msk.html}
 */
declare const KafkaMskEventSchema: z.ZodObject<{
    bootstrapServers: z.ZodOptional<z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<string[], string>>>>;
    records: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodObject<{
        topic: z.ZodString;
        partition: z.ZodNumber;
        offset: z.ZodNumber;
        timestamp: z.ZodNumber;
        timestampType: z.ZodString;
        key: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
        value: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
        headers: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodPipe<z.ZodArray<z.ZodNumber>, z.ZodTransform<string, number[]>>>>;
    }, z.core.$strip>>>;
    eventSource: z.ZodLiteral<"aws:kafka">;
    eventSourceArn: z.ZodString;
}, z.core.$strip>;
export { KafkaSelfManagedEventSchema, KafkaMskEventSchema, KafkaRecordSchema };
//# sourceMappingURL=kafka.d.ts.map