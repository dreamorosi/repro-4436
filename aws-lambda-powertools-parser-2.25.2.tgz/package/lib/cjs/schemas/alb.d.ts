import { z } from 'zod';
/**
 * Zod schema for Application Load Balancer events.
 *
 * @example
 * ```json
 * {
 *   "requestContext": {
 *     "elb": {
 *       "targetGroupArn": "arn:aws:elasticloadbalancing:region:123456789012:targetgroup/my-target-group/6d0ecf831eec9f09"
 *     }
 *   },
 *   "httpMethod": "GET",
 *   "path": "/",
 *   "queryStringParameters": {
 *     parameters
 *   },
 *   "headers": {
 *     "accept": "text/html,application/xhtml+xml",
 *     "accept-language": "en-US,en;q=0.8",
 *     "content-type": "text/plain",
 *     "cookie": "cookies",
 *     "host": "lambda-846800462-us-east-2.elb.amazonaws.com",
 *     "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6)",
 *     "x-amzn-trace-id": "Root=1-5bdb40ca-556d8b0c50dc66f0511bf520",
 *     "x-forwarded-for": "72.21.198.66",
 *     "x-forwarded-port": "443",
 *     "x-forwarded-proto": "https"
 *   },
 *   "isBase64Encoded": false,
 *   "body": "request_body"
 * }
 * ```
 *
 * With multi-value headers and multi-value query string parameters:
 *
 * @example
 * ```json
 * {
 *   "requestContext": {
 *     "elb": {
 *       "targetGroupArn": "arn:aws:elasticloadbalancing:region:123456789012:targetgroup/my-target-group/6d0ecf831eec9f09"
 *     }
 *   },
 *   "httpMethod": "GET",
 *   "path": "/",
 *   "multiValueHeaders": {
 *     "Set-cookie": [
 *       "cookie-name=cookie-value;Domain=myweb.com;Secure;HttpOnly",
 *       "cookie-name=cookie-value;Expires=May 8, 2019"
 *     ],
 *     "Content-Type": [
 *       "application/json"
 *     ]
 *   },
 *   "isBase64Encoded": false,
 *   "body": "request_body"
 * }
 * ```
 *
 * @see {@link ALBEvent | `ALBEvent`}
 * @see {@link https://docs.aws.amazon.com/elasticloadbalancing/latest/application/lambda-functions.html}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/services-alb.html}
 */
declare const AlbSchema: z.ZodObject<{
    httpMethod: z.ZodString;
    path: z.ZodString;
    body: z.ZodString;
    isBase64Encoded: z.ZodBoolean;
    headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    multiValueHeaders: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    queryStringParameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    multiValueQueryStringParameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    requestContext: z.ZodObject<{
        elb: z.ZodObject<{
            targetGroupArn: z.ZodString;
        }, z.core.$strip>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * @deprecated Use {@link AlbSchema | `AlbSchema`} instead, which handles both types of headers & querystring parameters.
 *
 * This schema will be removed in a future major release.
 */
declare const AlbMultiValueHeadersSchema: z.ZodObject<{
    httpMethod: z.ZodString;
    path: z.ZodString;
    body: z.ZodString;
    isBase64Encoded: z.ZodBoolean;
    headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    queryStringParameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    requestContext: z.ZodObject<{
        elb: z.ZodObject<{
            targetGroupArn: z.ZodString;
        }, z.core.$strip>;
    }, z.core.$strip>;
    multiValueHeaders: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
    multiValueQueryStringParameters: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export { AlbSchema, AlbMultiValueHeadersSchema };
//# sourceMappingURL=alb.d.ts.map