import { z } from 'zod';
declare const SqsMsgAttributeDataTypeSchema: z.ZodUnion<readonly [z.ZodLiteral<"String">, z.ZodLiteral<"Number">, z.ZodLiteral<"Binary">, z.ZodString]>;
declare const SqsMsgAttributeSchema: z.ZodObject<{
    stringValue: z.ZodOptional<z.ZodString>;
    binaryValue: z.ZodOptional<z.ZodString>;
    stringListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
    binaryListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
    dataType: z.ZodUnion<readonly [z.ZodLiteral<"String">, z.ZodLiteral<"Number">, z.ZodLiteral<"Binary">, z.ZodString]>;
}, z.core.$strip>;
declare const SqsAttributesSchema: z.ZodObject<{
    ApproximateReceiveCount: z.ZodString;
    ApproximateFirstReceiveTimestamp: z.ZodString;
    MessageDeduplicationId: z.ZodOptional<z.ZodString>;
    MessageGroupId: z.ZodOptional<z.ZodString>;
    SenderId: z.ZodString;
    SentTimestamp: z.ZodString;
    SequenceNumber: z.ZodOptional<z.ZodString>;
    AWSTraceHeader: z.ZodOptional<z.ZodString>;
    DeadLetterQueueSourceArn: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/**
 * Zod schema for a SQS record inside an SQS event.
 */
declare const SqsRecordSchema: z.ZodObject<{
    messageId: z.ZodString;
    receiptHandle: z.ZodString;
    body: z.ZodString;
    attributes: z.ZodObject<{
        ApproximateReceiveCount: z.ZodString;
        ApproximateFirstReceiveTimestamp: z.ZodString;
        MessageDeduplicationId: z.ZodOptional<z.ZodString>;
        MessageGroupId: z.ZodOptional<z.ZodString>;
        SenderId: z.ZodString;
        SentTimestamp: z.ZodString;
        SequenceNumber: z.ZodOptional<z.ZodString>;
        AWSTraceHeader: z.ZodOptional<z.ZodString>;
        DeadLetterQueueSourceArn: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    messageAttributes: z.ZodRecord<z.ZodString, z.ZodObject<{
        stringValue: z.ZodOptional<z.ZodString>;
        binaryValue: z.ZodOptional<z.ZodString>;
        stringListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
        binaryListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
        dataType: z.ZodUnion<readonly [z.ZodLiteral<"String">, z.ZodLiteral<"Number">, z.ZodLiteral<"Binary">, z.ZodString]>;
    }, z.core.$strip>>;
    md5OfBody: z.ZodString;
    md5OfMessageAttributes: z.ZodOptional<z.ZodString>;
    eventSource: z.ZodLiteral<"aws:sqs">;
    eventSourceARN: z.ZodString;
    awsRegion: z.ZodString;
}, z.core.$strip>;
/**
 * Zod schema for SQS event
 *
 * @example
 * ```json
 * {
 *   "Records": [
 *     {
 *       "messageId": "059f36b4-87a3-44ab-83d2-661975830a7d",
 *       "receiptHandle": "AQEBwJnKyrHigUMZj6rYigCgxlaS3SLy0a...",
 *       "body": "Test message.",
 *       "attributes": {
 *         "ApproximateReceiveCount": "1",
 *         "SentTimestamp": "1545082649183",
 *         "SenderId": "AIDAIENQZJOLO23YVJ4VO",
 *         "ApproximateFirstReceiveTimestamp": "1545082649185"
 *       },
 *       "messageAttributes": {
 *         "testAttr": {
 *           "stringValue": "100",
 *           "binaryValue": "base64Str",
 *           "dataType": "Number"
 *         }
 *       },
 *       "md5OfBody": "e4e68fb7bd0e697a0ae8f1bb342846b3",
 *       "eventSource": "aws:sqs",
 *       "eventSourceARN": "arn:aws:sqs:us-east-2:123456789012:my-queue",
 *       "awsRegion": "us-east-2"
 *     },
 *     {
 *       "messageId": "2e1424d4-f796-459a-8184-9c92662be6da",
 *       "receiptHandle": "AQEBzWwaftRI0KuVm4tP+/7q1rGgNqicHq...",
 *       "body": "{\"message\": \"foo1\"}",
 *       "attributes": {
 *         "ApproximateReceiveCount": "1",
 *         "SentTimestamp": "1545082650636",
 *         "SenderId": "AIDAIENQZJOLO23YVJ4VO",
 *         "ApproximateFirstReceiveTimestamp": "1545082650649",
 *         "DeadLetterQueueSourceArn": "arn:aws:sqs:us-east-2:123456789012:my-queue-dead"
 *       },
 *       "messageAttributes": {},
 *       "md5OfBody": "e4e68fb7bd0e697a0ae8f1bb342846b3",
 *       "eventSource": "aws:sqs",
 *       "eventSourceARN": "arn:aws:sqs:us-east-2:123456789012:my-queue",
 *       "awsRegion": "us-east-2"
 *     }
 *   ]
 * }
 * ```
 *
 * @see {@link SqsEvent | `SqsEvent`}
 * @see {@link https://docs.aws.amazon.com/lambda/latest/dg/with-sqs.html#example-standard-queue-message-event}
 */
declare const SqsSchema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        messageId: z.ZodString;
        receiptHandle: z.ZodString;
        body: z.ZodString;
        attributes: z.ZodObject<{
            ApproximateReceiveCount: z.ZodString;
            ApproximateFirstReceiveTimestamp: z.ZodString;
            MessageDeduplicationId: z.ZodOptional<z.ZodString>;
            MessageGroupId: z.ZodOptional<z.ZodString>;
            SenderId: z.ZodString;
            SentTimestamp: z.ZodString;
            SequenceNumber: z.ZodOptional<z.ZodString>;
            AWSTraceHeader: z.ZodOptional<z.ZodString>;
            DeadLetterQueueSourceArn: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        messageAttributes: z.ZodRecord<z.ZodString, z.ZodObject<{
            stringValue: z.ZodOptional<z.ZodString>;
            binaryValue: z.ZodOptional<z.ZodString>;
            stringListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
            binaryListValues: z.ZodOptional<z.ZodArray<z.ZodString>>;
            dataType: z.ZodUnion<readonly [z.ZodLiteral<"String">, z.ZodLiteral<"Number">, z.ZodLiteral<"Binary">, z.ZodString]>;
        }, z.core.$strip>>;
        md5OfBody: z.ZodString;
        md5OfMessageAttributes: z.ZodOptional<z.ZodString>;
        eventSource: z.ZodLiteral<"aws:sqs">;
        eventSourceARN: z.ZodString;
        awsRegion: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export { SqsSchema, SqsRecordSchema, SqsMsgAttributeSchema, SqsMsgAttributeDataTypeSchema, SqsAttributesSchema, };
//# sourceMappingURL=sqs.d.ts.map