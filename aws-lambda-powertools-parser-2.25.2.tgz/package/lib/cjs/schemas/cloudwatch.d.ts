import { z } from 'zod';
declare const CloudWatchLogEventSchema: z.ZodObject<{
    id: z.ZodString;
    timestamp: z.ZodNumber;
    message: z.ZodString;
}, z.core.$strip>;
declare const CloudWatchLogsDecodeSchema: z.ZodObject<{
    messageType: z.ZodString;
    owner: z.ZodString;
    logGroup: z.ZodString;
    logStream: z.ZodString;
    subscriptionFilters: z.ZodArray<z.ZodString>;
    logEvents: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        timestamp: z.ZodNumber;
        message: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Zod schema for CloudWatch Logs.
 *
 * @example
 * ```json
 * {
 *   "awslogs": {
 *     "data": "H4sIAAAAAAAAAHWPwQqCQBCGX0Xm7EFtK+smZBEUgXoLCdMhFtKV3akI8d0bLYmibvPPN3wz00CJxmQnTO41whwWQRIctmEcB6sQbFC3CjW3XW8kxpOpP+OC22d1Wml1qZkQGtoMsScxaczKN3plG8zlaHIta5KqWsozoTYw3/djzwhpLwivWFGHGpAFe7DL68JlBUk+l7KSN7tCOEJ4M3/qOI49vMHj+zCKdlFqLaU2ZHV2a4Ct/an0/ivdX8oYc1UVX860fQDQiMdxRQEAAA=="
 *   }
 * }
 * ```
 * The `data` field compressed JSON string, once transformed the payload will look like:
 *
 * @example
 * ```json
 * {
 *   "owner": "123456789012",
 *   "logGroup": "CloudTrail",
 *   "logStream": "123456789012_CloudTrail_us-east-1",
 *   "subscriptionFilters": [
 *     "Destination"
 *   ],
 *   "messageType": "DATA_MESSAGE",
 *   "logEvents": [
 *     {
 *       "id": "31953106606966983378809025079804211143289615424298221568",
 *       "timestamp": 1432826855000,
 *       "message": "{\"eventVersion\":\"1.03\",\"userIdentity\":{\"type\":\"Root\"}"
 *     },
 *     {
 *       "id": "31953106606966983378809025079804211143289615424298221569",
 *       "timestamp": 1432826855000,
 *       "message": "{\"eventVersion\":\"1.03\",\"userIdentity\":{\"type\":\"Root\"}"
 *     },
 *     {
 *       "id": "31953106606966983378809025079804211143289615424298221570",
 *       "timestamp": 1432826855000,
 *       "message": "{\"eventVersion\":\"1.03\",\"userIdentity\":{\"type\":\"Root\"}"
 *     }
 *   ]
 * }
 * ```
 *
 * @see {@link CloudWatchLogsEvent | `CloudWatchLogsEvent`}
 * @see {@link https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/SubscriptionFilters.html#LambdaFunctionExample}
 */
declare const CloudWatchLogsSchema: z.ZodObject<{
    awslogs: z.ZodObject<{
        data: z.ZodPipe<z.ZodBase64, z.ZodTransform<{
            messageType: string;
            owner: string;
            logGroup: string;
            logStream: string;
            subscriptionFilters: string[];
            logEvents: {
                id: string;
                timestamp: number;
                message: string;
            }[];
        }, string>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export { CloudWatchLogsSchema, CloudWatchLogsDecodeSchema, CloudWatchLogEventSchema, };
//# sourceMappingURL=cloudwatch.d.ts.map