import { z } from 'zod';
import { AppSyncCognitoIdentity, AppSyncIamIdentity, AppSyncOidcIdentity } from './appsync-shared.js';
declare const AppSyncLambdaIdentity: z.ZodObject<{
    resolverContext: z.ZodAny;
}, z.core.$strip>;
/**
 * A zod schema for an AppSync resolver event
 *
 * @example
 * ```json
 * {
 *   "arguments": {
 *     "id": "1973493"
 *   },
 *   "source": null,
 *   "identity": {
 *     "accountId": "012345678901",
 *     "cognitoIdentityAuthProvider": null,
 *     "cognitoIdentityAuthType": null,
 *     "cognitoIdentityId": null,
 *     "cognitoIdentityPoolId": null,
 *     "sourceIp": ["10.10.10.10"],
 *     "userArn": "arn:aws:sts::012345678901:assumed-role/role",
 *     "username": "AROAXYKJUOW6FHGUSK5FA:username"
 *   },
 *   "request": {
 *     "headers": {
 *       "x-forwarded-for": "1.1.1.1, 2.2.2.2",
 *       "cloudfront-viewer-country": "US",
 *       "cloudfront-is-tablet-viewer": "false",
 *       "via": "2.0 xxxxxxxxxxxxxxxx.cloudfront.net (CloudFront)",
 *       "cloudfront-forwarded-proto": "https",
 *       "origin": "https://us-west-1.console.aws.amazon.com",
 *       "content-length": "217",
 *       "accept-language": "en-US,en;q=0.9",
 *       "host": "xxxxxxxxxxxxxxxx.appsync-api.us-west-1.amazonaws.com",
 *       "x-forwarded-proto": "https",
 *       "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36",
 *       "accept": "*!/!*",
 *       "cloudfront-is-mobile-viewer": "false",
 *       "cloudfront-is-smarttv-viewer": "false",
 *       "accept-encoding": "gzip, deflate, br",
 *       "referer": "https://us-west-1.console.aws.amazon.com/appsync/home?region=us-west-1",
 *       "content-type": "application/json",
 *       "sec-fetch-mode": "cors",
 *       "x-amz-cf-id": "3aykhqlUwQeANU-HGY7E_guV5EkNeMMtwyOgiA==",
 *       "x-amzn-trace-id": "Root=1-5f512f51-fac632066c5e848ae714",
 *       "authorization": "eyJraWQiOiJScWFCSlJqYVJlM0hrSnBTUFpIcVRXazNOW...",
 *       "sec-fetch-dest": "empty",
 *       "x-amz-user-agent": "AWS-Console-AppSync/",
 *       "cloudfront-is-desktop-viewer": "true",
 *       "sec-fetch-site": "cross-site",
 *       "x-forwarded-port": "443"
 *     }
 *   },
 *   "prev": {
 *     "result": {}
 *   },
 *   "info": {
 *     "selectionSetList": ["id", "field1", "field2"],
 *     "selectionSetGraphQL": "{\n  id\n  field1\n  field2\n}",
 *     "parentTypeName": "Mutation",
 *     "fieldName": "createSomething",
 *     "variables": {}
 *   },
 *   "stash": {}
 * }
 * ```
 *
 * @see {@link AppSyncResolverEvent | `AppSyncResolverEvent`}
 * @see {@link https://docs.aws.amazon.com/appsync/latest/devguide/resolver-context-reference-js.html}
 */
declare const AppSyncResolverSchema: z.ZodObject<{
    arguments: z.ZodRecord<z.ZodString, z.ZodAny>;
    identity: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        sub: z.ZodString;
        issuer: z.ZodString;
        username: z.ZodString;
        claims: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        sourceIp: z.ZodArray<z.ZodIPv4>;
        defaultAuthStrategy: z.ZodNullable<z.ZodString>;
        groups: z.ZodNullable<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        accountId: z.ZodString;
        cognitoIdentityPoolId: z.ZodNullable<z.ZodString>;
        cognitoIdentityId: z.ZodNullable<z.ZodString>;
        sourceIp: z.ZodArray<z.ZodString>;
        username: z.ZodString;
        userArn: z.ZodString;
        cognitoIdentityAuthType: z.ZodNullable<z.ZodString>;
        cognitoIdentityAuthProvider: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        claims: z.ZodAny;
        issuer: z.ZodString;
        sub: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        resolverContext: z.ZodAny;
    }, z.core.$strip>]>>;
    source: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>;
    request: z.ZodObject<{
        domainName: z.ZodNullable<z.ZodString>;
        headers: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strip>;
    info: z.ZodObject<{
        selectionSetList: z.ZodArray<z.ZodString>;
        selectionSetGraphQL: z.ZodString;
        parentTypeName: z.ZodString;
        fieldName: z.ZodString;
        variables: z.ZodRecord<z.ZodString, z.ZodAny>;
    }, z.core.$strip>;
    prev: z.ZodNullable<z.ZodObject<{
        result: z.ZodRecord<z.ZodString, z.ZodAny>;
    }, z.core.$strip>>;
    stash: z.ZodRecord<z.ZodString, z.ZodAny>;
}, z.core.$strip>;
/**
 * A zod schema for a batch AppSync resolver event
 *
 * @example
 * ```json
 * [{
 *   "arguments": {
 *     "id": "1973493"
 *   },
 *   "source": null,
 *   "identity": {
 *     "accountId": "012345678901",
 *     "cognitoIdentityAuthProvider": "cognitoIdentityAuthProvider",
 *     "cognitoIdentityAuthType": "cognitoIdentityAuthType",
 *     "cognitoIdentityId": "cognitoIdentityId",
 *     "cognitoIdentityPoolId": "cognitoIdentityPoolId",
 *     "sourceIp": ["10.10.10.10"],
 *     "userArn": "arn:aws:sts::012345678901:assumed-role/role",
 *     "username": "AROAXYKJUOW6FHGUSK5FA:username"
 *   },
 *   "request": {
 *     "headers": {
 *       "x-forwarded-for": "1.1.1.1, 2.2.2.2",
 *         "cloudfront-viewer-country": "US",
 *         "cloudfront-is-tablet-viewer": "false",
 *         "via": "2.0 xxxxxxxxxxxxxxxx.cloudfront.net (CloudFront)",
 *         "cloudfront-forwarded-proto": "https",
 *         "origin": "https://us-west-1.console.aws.amazon.com",
 *         "content-length": "217",
 *         "accept-language": "en-US,en;q=0.9",
 *         "host": "xxxxxxxxxxxxxxxx.appsync-api.us-west-1.amazonaws.com",
 *         "x-forwarded-proto": "https",
 *         "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36",
 *         "accept": "*!/!*",
 *         "cloudfront-is-mobile-viewer": "false",
 *         "cloudfront-is-smarttv-viewer": "false",
 *         "accept-encoding": "gzip, deflate, br",
 *         "referer": "https://us-west-1.console.aws.amazon.com/appsync/home?region=us-west-1",
 *         "content-type": "application/json",
 *         "sec-fetch-mode": "cors",
 *         "x-amz-cf-id": "3aykhqlUwQeANU-HGY7E_guV5EkNeMMtwyOgiA==",
 *         "x-amzn-trace-id": "Root=1-5f512f51-fac632066c5e848ae714",
 *         "authorization": "eyJraWQiOiJScWFCSlJqYVJlM0hrSnBTUFpIcVRXazNOW...",
 *         "sec-fetch-dest": "empty",
 *         "x-amz-user-agent": "AWS-Console-AppSync/",
 *         "cloudfront-is-desktop-viewer": "true",
 *         "sec-fetch-site": "cross-site",
 *         "x-forwarded-port": "443"
 *     }
 *   },
 *   "prev": {
 *     "result": {}
 *   },
 *   "info": {
 *     "selectionSetList": ["id", "field1", "field2"],
 *     "selectionSetGraphQL": "{\n  id\n  field1\n  field2\n}",
 *     "parentTypeName": "Mutation",
 *     "fieldName": "createSomething",
 *     "variables": {}
 *   },
 *   "stash": {}
 * },
 * {
 *   "arguments": {
 *     "id": "1987311"
 *   },
 *   "source": null,
 *   "identity": {
 *     "claims": {
 *       "sub": "sub"
 *     },
 *     "issuer": "issuer",
 *     "sub": "sub
 *   },
 *   "request": {
 *     "headers": {
 *       "x-forwarded-for": "1.1.1.1, 2.2.2.2",
 *         "cloudfront-viewer-country": "US",
 *         "cloudfront-is-tablet-viewer": "false",
 *         "via": "2.0 xxxxxxxxxxxxxxxx.cloudfront.net (CloudFront)",
 *         "cloudfront-forwarded-proto": "https",
 *         "origin": "https://us-west-1.console.aws.amazon.com",
 *         "content-length": "217",
 *         "accept-language": "en-US,en;q=0.9",
 *         "host": "xxxxxxxxxxxxxxxx.appsync-api.us-west-1.amazonaws.com",
 *         "x-forwarded-proto": "https",
 *         "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36",
 *         "accept": "*!/!*",
 *         "cloudfront-is-mobile-viewer": "false",
 *         "cloudfront-is-smarttv-viewer": "false",
 *         "accept-encoding": "gzip, deflate, br",
 *         "referer": "https://us-west-1.console.aws.amazon.com/appsync/home?region=us-west-1",
 *         "content-type": "application/json",
 *         "sec-fetch-mode": "cors",
 *         "x-amz-cf-id": "3aykhqlUwQeANU-HGY7E_guV5EkNeMMtwyOgiA==",
 *         "x-amzn-trace-id": "Root=1-5f512f51-fac632066c5e848ae714",
 *         "authorization": "eyJraWQiOiJScWFCSlJqYVJlM0hrSnBTUFpIcVRXazNOW...",
 *         "sec-fetch-dest": "empty",
 *         "x-amz-user-agent": "AWS-Console-AppSync/",
 *         "cloudfront-is-desktop-viewer": "true",
 *         "sec-fetch-site": "cross-site",
 *         "x-forwarded-port": "443"
 *     }
 *   },
 *   "prev": {
 *     "result": {}
 *   },
 *   "info": {
 *     "selectionSetList": ["id", "field1", "field2"],
 *     "selectionSetGraphQL": "{\n  id\n  field1\n  field2\n}",
 *     "parentTypeName": "Mutation",
 *     "fieldName": "createSomething",
 *     "variables": {}
 *   },
 *   "stash": {}
 * }]
 * ```
 *
 * @see {@link AppSyncBatchResolverEvent | `AppSyncBatchResolverEvent`}
 * @see {@link https://docs.aws.amazon.com/appsync/latest/devguide/tutorial-lambda-resolvers.html#advanced-use-case-batching}
 */
declare const AppSyncBatchResolverSchema: z.ZodArray<z.ZodObject<{
    arguments: z.ZodRecord<z.ZodString, z.ZodAny>;
    identity: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        sub: z.ZodString;
        issuer: z.ZodString;
        username: z.ZodString;
        claims: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        sourceIp: z.ZodArray<z.ZodIPv4>;
        defaultAuthStrategy: z.ZodNullable<z.ZodString>;
        groups: z.ZodNullable<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        accountId: z.ZodString;
        cognitoIdentityPoolId: z.ZodNullable<z.ZodString>;
        cognitoIdentityId: z.ZodNullable<z.ZodString>;
        sourceIp: z.ZodArray<z.ZodString>;
        username: z.ZodString;
        userArn: z.ZodString;
        cognitoIdentityAuthType: z.ZodNullable<z.ZodString>;
        cognitoIdentityAuthProvider: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        claims: z.ZodAny;
        issuer: z.ZodString;
        sub: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        resolverContext: z.ZodAny;
    }, z.core.$strip>]>>;
    source: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>;
    request: z.ZodObject<{
        domainName: z.ZodNullable<z.ZodString>;
        headers: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strip>;
    info: z.ZodObject<{
        selectionSetList: z.ZodArray<z.ZodString>;
        selectionSetGraphQL: z.ZodString;
        parentTypeName: z.ZodString;
        fieldName: z.ZodString;
        variables: z.ZodRecord<z.ZodString, z.ZodAny>;
    }, z.core.$strip>;
    prev: z.ZodNullable<z.ZodObject<{
        result: z.ZodRecord<z.ZodString, z.ZodAny>;
    }, z.core.$strip>>;
    stash: z.ZodRecord<z.ZodString, z.ZodAny>;
}, z.core.$strip>>;
export { AppSyncResolverSchema, AppSyncBatchResolverSchema, AppSyncCognitoIdentity, AppSyncIamIdentity, AppSyncOidcIdentity, AppSyncLambdaIdentity, };
//# sourceMappingURL=appsync.d.ts.map