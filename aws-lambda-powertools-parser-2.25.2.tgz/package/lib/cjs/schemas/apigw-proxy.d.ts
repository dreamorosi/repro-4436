import { z } from 'zod';
/**
 * A zod schema for an API Gateway Certificate
 */
declare const APIGatewayCert: z.ZodObject<{
    clientCertPem: z.ZodString;
    subjectDN: z.ZodString;
    issuerDN: z.ZodString;
    serialNumber: z.ZodString;
    validity: z.ZodObject<{
        notBefore: z.ZodString;
        notAfter: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * A zod schema for an object with string keys and string values
 */
declare const APIGatewayRecord: z.ZodRecord<z.ZodString, z.ZodString>;
/**
 * A zod schema for an array of strings
 */
declare const APIGatewayStringArray: z.ZodArray<z.ZodString>;
/**
 * A zod schema for API Gateway HTTP methods
 */
declare const APIGatewayHttpMethod: z.ZodEnum<{
    GET: "GET";
    POST: "POST";
    PUT: "PUT";
    PATCH: "PATCH";
    DELETE: "DELETE";
    HEAD: "HEAD";
    OPTIONS: "OPTIONS";
}>;
export { APIGatewayCert, APIGatewayRecord, APIGatewayStringArray, APIGatewayHttpMethod, };
//# sourceMappingURL=apigw-proxy.d.ts.map