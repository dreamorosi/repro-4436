import { z } from 'zod';
/**
 * Zod schema for VPC Lattice event
 *
 * @example
 * ```json
 * {
  "raw_path": "/testpath",
 * "method": "GET",
 * "headers": {
 *   "user_agent": "curl/7.64.1",
 *   "x-forwarded-for": "10.213.229.10",
 *   "host": "test-lambda-service-3908sdf9u3u.dkfjd93.vpc-lattice-svcs.us-east-2.on.aws",
 *   "accept": "*\/*",
 * },
 * "query_string_parameters": {
 *   "order-id": "1"
 * },
 * "body": "eyJ0ZXN0IjogImV2ZW50In0=",
 * "is_base64_encoded": true
 *}
 * ```
 *
 * @see {@link VpcLatticeEvent | `VpcLatticeEvent`}
 * @see {@link https://docs.aws.amazon.com/vpc-lattice/latest/ug/lambda-functions.html#receive-event-from-service}
 */
declare const VpcLatticeSchema: z.ZodObject<{
    method: z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        HEAD: "HEAD";
        OPTIONS: "OPTIONS";
    }>;
    raw_path: z.ZodString;
    body: z.ZodString;
    is_base64_encoded: z.ZodBoolean;
    headers: z.ZodRecord<z.ZodString, z.ZodString>;
    query_string_parameters: z.ZodRecord<z.ZodString, z.ZodString>;
}, z.core.$strip>;
export { VpcLatticeSchema };
//# sourceMappingURL=vpc-lattice.d.ts.map