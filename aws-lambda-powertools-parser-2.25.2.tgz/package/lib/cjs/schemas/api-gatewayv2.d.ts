import { z } from 'zod';
/**
 * A zod schema for an API Gateway HTTP API Request Authorizer
 *
 * If Lambda authorizer is used, the `lambda` property will be set to an object
 * containing the `context` object returned by the Lambda authorizer function.
 * If no `context` object is returned, the `lambda` property will be set to `null`.
 *
 * If JWT authorizer is used, the `jwt` property will be set to an object
 * containing the `claims` object returned by the JWT authorizer function. Optionally,
 * the `scopes` property will be set to an array of scopes returned by the JWT authorizer.
 *
 * @example
 * ```json
 * {
 *   "jwt": {
 *     "claims": {
 *       "claim1": "value1",
 *       "claim2": "value2"
 *     },
 *     "scopes": [
 *       "scope1",
 *       "scope2"
 *     ]
 *   }
 * }
 * ```
 *
 * If IAM authorizer is used, the `iam` property will be set to an object
 * containing the details of the IAM user making the request.
 *
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-access-control.html}
 */
declare const APIGatewayRequestAuthorizerV2Schema: z.ZodObject<{
    jwt: z.ZodOptional<z.ZodObject<{
        claims: z.ZodRecord<z.ZodString, z.ZodAny>;
        scopes: z.ZodNullable<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    iam: z.ZodOptional<z.ZodObject<{
        accessKey: z.ZodOptional<z.ZodString>;
        accountId: z.ZodOptional<z.ZodString>;
        callerId: z.ZodOptional<z.ZodString>;
        principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        userArn: z.ZodOptional<z.ZodString>;
        userId: z.ZodOptional<z.ZodString>;
        cognitoIdentity: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            amr: z.ZodArray<z.ZodString>;
            identityId: z.ZodString;
            identityPoolId: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>>;
    lambda: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
}, z.core.$strip>;
/**
 * A zod schema for an API Gateway HTTP API Request Context
 *
 * @example
 * ```json
 * {
 *   "accountId": "123456789012",
 *   "apiId": "api-id",
 *   "authentication": {}
 *   "domainName": "id.execute-api.us-east-1.amazonaws.com",
 *   "domainPrefix": "id",
 *   "http": {
 *     "method": "POST",
 *     "path": "/my/path",
 *     "protocol": "HTTP/1.1",
 *     "sourceIp": "...",
 *     "userAgent": "..."
 *   },
 *   "requestId": "...",
 *   "routeKey": "$default",
 *   "stage": "$default",
 *   "time": "12/Mar/2020:19:03:58 +0000",
 *   "timeEpoch": 1583348638390
 * }
 * ```
 */
declare const APIGatewayRequestContextV2Schema: z.ZodObject<{
    accountId: z.ZodString;
    apiId: z.ZodString;
    authorizer: z.ZodOptional<z.ZodObject<{
        jwt: z.ZodOptional<z.ZodObject<{
            claims: z.ZodRecord<z.ZodString, z.ZodAny>;
            scopes: z.ZodNullable<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>>;
        iam: z.ZodOptional<z.ZodObject<{
            accessKey: z.ZodOptional<z.ZodString>;
            accountId: z.ZodOptional<z.ZodString>;
            callerId: z.ZodOptional<z.ZodString>;
            principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            userArn: z.ZodOptional<z.ZodString>;
            userId: z.ZodOptional<z.ZodString>;
            cognitoIdentity: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                amr: z.ZodArray<z.ZodString>;
                identityId: z.ZodString;
                identityPoolId: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>>;
        lambda: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
    }, z.core.$strip>>;
    authentication: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        clientCert: z.ZodOptional<z.ZodObject<{
            clientCertPem: z.ZodString;
            subjectDN: z.ZodString;
            issuerDN: z.ZodString;
            serialNumber: z.ZodString;
            validity: z.ZodObject<{
                notBefore: z.ZodString;
                notAfter: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>>;
    }, z.core.$strip>>>;
    domainName: z.ZodString;
    domainPrefix: z.ZodString;
    http: z.ZodObject<{
        method: z.ZodEnum<{
            GET: "GET";
            POST: "POST";
            PUT: "PUT";
            PATCH: "PATCH";
            DELETE: "DELETE";
            HEAD: "HEAD";
            OPTIONS: "OPTIONS";
        }>;
        path: z.ZodString;
        protocol: z.ZodString;
        sourceIp: z.ZodUnion<readonly [z.ZodIPv4, z.ZodIPv6]>;
        userAgent: z.ZodString;
    }, z.core.$strip>;
    requestId: z.ZodString;
    routeKey: z.ZodString;
    stage: z.ZodString;
    time: z.ZodString;
    timeEpoch: z.ZodNumber;
}, z.core.$strip>;
/**
 * A zod schema for an API Gateway HTTP API Proxy event
 *
 * @example
 * ```json
 * {
 *   "version": "2.0",
 *   "routeKey": "$default",
 *   "rawPath": "/my/path",
 *   "rawQueryString": "parameter1=value1&parameter1=value2&parameter2=value",
 *   "cookies": ["cookie1", "cookie2"],
 *   "headers": {
 *     "header1": "value1",
 *     "header2": "value1,value2"
 *   },
 *   "queryStringParameters": {
 *     "parameter1": "value1,value2",
 *     "parameter2": "value"
 *   },
 *   "requestContext": {
 *     "accountId": "123456789012",
 *     "apiId": "api-id",
 *     "authentication": {}
 *     "domainName": "id.execute-api.us-east-1.amazonaws.com",
 *     "domainPrefix": "id",
 *     "http": {
 *       "method": "POST",
 *       "path": "/my/path",
 *       "protocol": "HTTP/1.1",
 *       "sourceIp": "...",
 *       "userAgent": "..."
 *     },
 *     "requestId": "...",
 *     "routeKey": "$default",
 *     "stage": "$default",
 *     "time": "12/Mar/2020:19:03:58 +0000",
 *     "timeEpoch": 1583348638390
 *   },
 *   "body": "Hello from Lambda",
 *   "pathParameters": {},
 *   "isBase64Encoded": false,
 *   "stageVariables": {}
 * }
 * ```
 *
 * @see {@link APIGatewayProxyEventV2 | `APIGatewayProxyEventV2`}
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html}
 */
declare const APIGatewayProxyEventV2Schema: z.ZodObject<{
    version: z.ZodString;
    routeKey: z.ZodString;
    rawPath: z.ZodString;
    rawQueryString: z.ZodString;
    cookies: z.ZodOptional<z.ZodArray<z.ZodString>>;
    headers: z.ZodRecord<z.ZodString, z.ZodString>;
    queryStringParameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    requestContext: z.ZodObject<{
        accountId: z.ZodString;
        apiId: z.ZodString;
        authorizer: z.ZodOptional<z.ZodObject<{
            jwt: z.ZodOptional<z.ZodObject<{
                claims: z.ZodRecord<z.ZodString, z.ZodAny>;
                scopes: z.ZodNullable<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>>;
            iam: z.ZodOptional<z.ZodObject<{
                accessKey: z.ZodOptional<z.ZodString>;
                accountId: z.ZodOptional<z.ZodString>;
                callerId: z.ZodOptional<z.ZodString>;
                principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                userArn: z.ZodOptional<z.ZodString>;
                userId: z.ZodOptional<z.ZodString>;
                cognitoIdentity: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    amr: z.ZodArray<z.ZodString>;
                    identityId: z.ZodString;
                    identityPoolId: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>>;
            lambda: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
        }, z.core.$strip>>;
        authentication: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            clientCert: z.ZodOptional<z.ZodObject<{
                clientCertPem: z.ZodString;
                subjectDN: z.ZodString;
                issuerDN: z.ZodString;
                serialNumber: z.ZodString;
                validity: z.ZodObject<{
                    notBefore: z.ZodString;
                    notAfter: z.ZodString;
                }, z.core.$strip>;
            }, z.core.$strip>>;
        }, z.core.$strip>>>;
        domainName: z.ZodString;
        domainPrefix: z.ZodString;
        http: z.ZodObject<{
            method: z.ZodEnum<{
                GET: "GET";
                POST: "POST";
                PUT: "PUT";
                PATCH: "PATCH";
                DELETE: "DELETE";
                HEAD: "HEAD";
                OPTIONS: "OPTIONS";
            }>;
            path: z.ZodString;
            protocol: z.ZodString;
            sourceIp: z.ZodUnion<readonly [z.ZodIPv4, z.ZodIPv6]>;
            userAgent: z.ZodString;
        }, z.core.$strip>;
        requestId: z.ZodString;
        routeKey: z.ZodString;
        stage: z.ZodString;
        time: z.ZodString;
        timeEpoch: z.ZodNumber;
    }, z.core.$strip>;
    body: z.ZodOptional<z.ZodString>;
    pathParameters: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    isBase64Encoded: z.ZodBoolean;
    stageVariables: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
}, z.core.$strip>;
/**
 * A zod schema for an API Gateway HTTP API Request Authorizer event
 *
 * @example
 * ```json
 * {
 *   "version": "2.0",
 *   "type": "REQUEST",
 *   "routeArn": "arn:aws:execute-api:us-east-1:123456789012:api-id/stage-name/GET/mydemoresource",
 *   "identitySource": ["user1", "123"],
 *   "routeKey": "$default",
 *   "rawPath": "/mydemoresource",
 *   "rawQueryString": "parameter1=value1&parameter1=value2&parameter2=value",
 *   "cookies": ["cookie1", "cookie2"],
 *   "headers": {
 *     "header1": "value1",
 *     "header2": "value1,value2"
 *   },
 *   "queryStringParameters": {
 *     "parameter1": "value1,value2",
 *     "parameter2": "value"
 *   },
 *   "requestContext": {
 *     "accountId": "123456789012",
 *     "apiId": "api-id",
 *     "authentication": {}
 *     "domainName": "id.execute-api.us-east-1.amazonaws.com",
 *     "domainPrefix": "id",
 *     "http": {
 *       "method": "POST",
 *       "path": "/my/path",
 *       "protocol": "HTTP/1.1",
 *       "sourceIp": "...",
 *       "userAgent": "..."
 *     },
 *     "requestId": "...",
 *     "routeKey": "$default",
 *     "stage": "$default",
 *     "time": "12/Mar/2020:19:03:58 +0000",
 *     "timeEpoch": 1583348638390
 *   },
 *   "pathParameters": {},
 *   "stageVariables": {}
 * }
 * ```
 *
 * @see {@link APIGatewayRequestAuthorizerEventV2 | `APIGatewayRequestAuthorizerEventV2`}
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-lambda-authorizer.html}
 */
declare const APIGatewayRequestAuthorizerEventV2Schema: z.ZodObject<{
    version: z.ZodLiteral<"2.0">;
    type: z.ZodLiteral<"REQUEST">;
    routeArn: z.ZodString;
    identitySource: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    routeKey: z.ZodString;
    rawPath: z.ZodString;
    rawQueryString: z.ZodString;
    cookies: z.ZodOptional<z.ZodArray<z.ZodString>>;
    headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    queryStringParameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    requestContext: z.ZodObject<{
        accountId: z.ZodString;
        apiId: z.ZodString;
        authorizer: z.ZodOptional<z.ZodObject<{
            jwt: z.ZodOptional<z.ZodObject<{
                claims: z.ZodRecord<z.ZodString, z.ZodAny>;
                scopes: z.ZodNullable<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>>;
            iam: z.ZodOptional<z.ZodObject<{
                accessKey: z.ZodOptional<z.ZodString>;
                accountId: z.ZodOptional<z.ZodString>;
                callerId: z.ZodOptional<z.ZodString>;
                principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                userArn: z.ZodOptional<z.ZodString>;
                userId: z.ZodOptional<z.ZodString>;
                cognitoIdentity: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                    amr: z.ZodArray<z.ZodString>;
                    identityId: z.ZodString;
                    identityPoolId: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>>;
            lambda: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
        }, z.core.$strip>>;
        authentication: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            clientCert: z.ZodOptional<z.ZodObject<{
                clientCertPem: z.ZodString;
                subjectDN: z.ZodString;
                issuerDN: z.ZodString;
                serialNumber: z.ZodString;
                validity: z.ZodObject<{
                    notBefore: z.ZodString;
                    notAfter: z.ZodString;
                }, z.core.$strip>;
            }, z.core.$strip>>;
        }, z.core.$strip>>>;
        domainName: z.ZodString;
        domainPrefix: z.ZodString;
        http: z.ZodObject<{
            method: z.ZodEnum<{
                GET: "GET";
                POST: "POST";
                PUT: "PUT";
                PATCH: "PATCH";
                DELETE: "DELETE";
                HEAD: "HEAD";
                OPTIONS: "OPTIONS";
            }>;
            path: z.ZodString;
            protocol: z.ZodString;
            sourceIp: z.ZodUnion<readonly [z.ZodIPv4, z.ZodIPv6]>;
            userAgent: z.ZodString;
        }, z.core.$strip>;
        requestId: z.ZodString;
        routeKey: z.ZodString;
        stage: z.ZodString;
        time: z.ZodString;
        timeEpoch: z.ZodNumber;
    }, z.core.$strip>;
    pathParameters: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    stageVariables: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
}, z.core.$strip>;
export { APIGatewayProxyEventV2Schema, APIGatewayRequestAuthorizerEventV2Schema, APIGatewayRequestAuthorizerV2Schema, APIGatewayRequestContextV2Schema, };
//# sourceMappingURL=api-gatewayv2.d.ts.map