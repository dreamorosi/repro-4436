import { z } from 'zod';
/**
 * Zod schema for VpcLatticeV2 event
 *
 * @example
 * ```json
 * {
 *   "version": "2.0",
 *   "path": "/newpath",
 *   "method": "GET",
 *   "headers": {
 *     "user_agent": "curl/7.64.1",
 *     "x-forwarded-for": "10.213.229.10",
 *     "host": "test-lambda-service-3908sdf9u3u.dkfjd93.vpc-lattice-svcs.us-east-2.on.aws",
 *     "accept": "*]/*"
 *   },
 *   "queryStringParameters": {
 *     "order-id": "1"
 *   },
 *   "body": "{\"message\": \"Hello from Lambda!\"}",
 *   "isBase64Encoded": false,
 *   "requestContext": {
 *     "serviceNetworkArn": "arn:aws:vpc-lattice:us-east-2:123456789012:servicenetwork/sn-0bf3f2882e9cc805a",
 *     "serviceArn": "arn:aws:vpc-lattice:us-east-2:123456789012:service/svc-0a40eebed65f8d69c",
 *     "targetGroupArn": "arn:aws:vpc-lattice:us-east-2:123456789012:targetgroup/tg-6d0ecf831eec9f09",
 *     "identity": {
 *       "sourceVpcArn": "arn:aws:ec2:region:123456789012:vpc/vpc-0b8276c84697e7339",
 *       "type": "AWS_IAM",
 *       "principal": "arn:aws:sts::123456789012:assumed-role/example-role/057d00f8b51257ba3c853a0f248943cf",
 *       "sessionName": "057d00f8b51257ba3c853a0f248943cf",
 *       "x509SanDns": "example.com"
 *     },
 *     "region": "us-east-2",
 *     "timeEpoch": "1696331543569073"
 *   }
 * }
 * ```
 * @see {@link VpcLatticeEventV2 | `VpcLatticeEventV2`}
 * @see {@link https://docs.aws.amazon.com/vpc-lattice/latest/ug/lambda-functions.html#receive-event-from-service}
 */
declare const VpcLatticeV2Schema: z.ZodObject<{
    version: z.ZodString;
    path: z.ZodString;
    method: z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        HEAD: "HEAD";
        OPTIONS: "OPTIONS";
    }>;
    headers: z.ZodRecord<z.ZodString, z.ZodString>;
    queryStringParameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    body: z.ZodOptional<z.ZodString>;
    isBase64Encoded: z.ZodOptional<z.ZodBoolean>;
    requestContext: z.ZodObject<{
        serviceNetworkArn: z.ZodString;
        serviceArn: z.ZodString;
        targetGroupArn: z.ZodString;
        region: z.ZodString;
        timeEpoch: z.ZodString;
        identity: z.ZodObject<{
            sourceVpcArn: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodString>;
            principal: z.ZodOptional<z.ZodString>;
            principalOrgId: z.ZodOptional<z.ZodString>;
            sessionName: z.ZodOptional<z.ZodString>;
            X509SubjectCn: z.ZodOptional<z.ZodString>;
            X509IssuerOu: z.ZodOptional<z.ZodString>;
            x509SanDns: z.ZodOptional<z.ZodString>;
            x509SanUri: z.ZodOptional<z.ZodString>;
            X509SanNameCn: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    }, z.core.$strip>;
}, z.core.$strip>;
export { VpcLatticeV2Schema };
//# sourceMappingURL=vpc-latticev2.d.ts.map