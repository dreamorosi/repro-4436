import { z } from 'zod';
/**
 * A zod schema for API Gateway Proxy WebSocket events.
 *
 * @example
 * ```json
 * {
 *   "type": "REQUEST",
 *   "methodArn": "arn:aws:execute-api:us-east-1:123456789012:abcdef123/default/$connect",
 *   "headers": {
 *     "Connection": "upgrade",
 *     "content-length": "0",
 *     "HeaderAuth1": "headerValue1",
 *     "Host": "abcdef123.execute-api.us-east-1.amazonaws.com",
 *     "Sec-WebSocket-Extensions": "permessage-deflate; client_max_window_bits",
 *     "Sec-WebSocket-Key": "...",
 *     "Sec-WebSocket-Version": "13",
 *     "Upgrade": "websocket",
 *     "X-Amzn-Trace-Id": "..."
 *   },
 *   "multiValueHeaders": {
 *     "Connection": [ "upgrade" ],
 *     "content-length": [ "0" ],
 *     "HeaderAuth1": [ "headerValue1" ],
 *     "Host": [ "abcdef123.execute-api.us-east-1.amazonaws.com" ],
 *     "Sec-WebSocket-Extensions": [ "permessage-deflate; client_max_window_bits" ],
 *     "Sec-WebSocket-Key": [ "..." ],
 *     "Sec-WebSocket-Version": [ "13" ],
 *     "Upgrade": [ "websocket" ],
 *     "X-Amzn-Trace-Id": [ "..." ]
 *   },
 *   "queryStringParameters": {
 *     "QueryString1": "queryValue1"
 *   },
 *   "multiValueQueryStringParameters": {
 *     "QueryString1": [ "queryValue1" ]
 *   },
 *   "stageVariables": {},
 *   "requestContext": {
 *     "routeKey": "$connect",
 *     "eventType": "CONNECT",
 *     "extendedRequestId": "...",
 *     "requestTime": "19/Jan/2023:21:13:26 +0000",
 *     "messageDirection": "IN",
 *     "stage": "default",
 *     "connectedAt": 1674162806344,
 *     "requestTimeEpoch": 1674162806345,
 *     "identity": {
 *       "sourceIp": "..."
 *     },
 *     "requestId": "...",
 *     "domainName": "abcdef123.execute-api.us-east-1.amazonaws.com",
 *     "connectionId": "...",
 *     "apiId": "abcdef123"
 *   },
 *   "isBase64Encoded": false,
 *   "body": null
 * }
 * ```
 *
 * @see {@link APIGatewayProxyWebsocketEvent | `APIGatewayProxyWebsocketEvent`}
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/websocket-api-develop-integrations.html}
 */
export declare const APIGatewayProxyWebsocketEventSchema: z.ZodObject<{
    type: z.ZodString;
    methodArn: z.ZodString;
    headers: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    multiValueHeaders: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
    queryStringParameters: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>;
    multiValueQueryStringParameters: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    stageVariables: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    requestContext: z.ZodObject<{
        routeKey: z.ZodString;
        eventType: z.ZodEnum<{
            CONNECT: "CONNECT";
            MESSAGE: "MESSAGE";
            DISCONNECT: "DISCONNECT";
        }>;
        extendedRequestId: z.ZodString;
        requestTime: z.ZodString;
        messageDirection: z.ZodEnum<{
            IN: "IN";
            OUT: "OUT";
        }>;
        stage: z.ZodString;
        connectedAt: z.ZodNumber;
        requestTimeEpoch: z.ZodNumber;
        identity: z.ZodObject<{
            sourceIp: z.ZodString;
            userAgent: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        requestId: z.ZodString;
        domainName: z.ZodString;
        connectionId: z.ZodString;
        apiId: z.ZodString;
    }, z.core.$strip>;
    isBase64Encoded: z.ZodBoolean;
    body: z.ZodNullable<z.ZodOptional<z.ZodString>>;
}, z.core.$strip>;
//# sourceMappingURL=api-gateway-websocket.d.ts.map