import { z } from 'zod';
declare const AppSyncIamIdentity: z.ZodObject<{
    accountId: z.ZodString;
    cognitoIdentityPoolId: z.ZodNullable<z.ZodString>;
    cognitoIdentityId: z.ZodNullable<z.ZodString>;
    sourceIp: z.ZodArray<z.ZodString>;
    username: z.ZodString;
    userArn: z.ZodString;
    cognitoIdentityAuthType: z.ZodNullable<z.ZodString>;
    cognitoIdentityAuthProvider: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const AppSyncCognitoIdentity: z.ZodObject<{
    sub: z.ZodString;
    issuer: z.ZodString;
    username: z.ZodString;
    claims: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    sourceIp: z.ZodArray<z.ZodIPv4>;
    defaultAuthStrategy: z.ZodNullable<z.ZodString>;
    groups: z.ZodNullable<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
declare const AppSyncOidcIdentity: z.ZodObject<{
    claims: z.ZodAny;
    issuer: z.ZodString;
    sub: z.ZodString;
}, z.core.$strip>;
export { AppSyncCognitoIdentity, AppSyncIamIdentity, AppSyncOidcIdentity };
//# sourceMappingURL=appsync-shared.d.ts.map