import { z } from 'zod';
/**
 * A zod schema for an API Gateway Event Request Context
 *
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-mapping-template-reference.html#context-variable-reference}
 */
declare const APIGatewayEventRequestContextSchema: z.ZodObject<{
    accountId: z.ZodString;
    apiId: z.ZodString;
    deploymentId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    authorizer: z.ZodOptional<z.ZodNullable<z.ZodUnion<readonly [z.ZodObject<{
        integrationLatency: z.ZodNumber;
        principalId: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        claims: z.ZodRecord<z.ZodString, z.ZodAny>;
        scopes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>]>>>;
    stage: z.ZodString;
    protocol: z.ZodString;
    identity: z.ZodObject<{
        accessKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        accountId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        apiKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        apiKeyId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        caller: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        cognitoAuthenticationProvider: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        cognitoAuthenticationType: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        cognitoIdentityId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        cognitoIdentityPoolId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sourceIp: z.ZodOptional<z.ZodUnion<readonly [z.ZodIPv4, z.ZodIPv6, z.ZodLiteral<"test-invoke-source-ip">]>>;
        user: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        userAgent: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        userArn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        clientCert: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            clientCertPem: z.ZodString;
            subjectDN: z.ZodString;
            issuerDN: z.ZodString;
            serialNumber: z.ZodString;
            validity: z.ZodObject<{
                notBefore: z.ZodString;
                notAfter: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>>>;
    }, z.core.$strip>;
    requestId: z.ZodString;
    requestTime: z.ZodString;
    requestTimeEpoch: z.ZodNumber;
    resourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    resourcePath: z.ZodString;
    domainName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    domainPrefix: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    extendedRequestId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    httpMethod: z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        HEAD: "HEAD";
        OPTIONS: "OPTIONS";
    }>;
    path: z.ZodString;
    connectedAt: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    connectionId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    eventType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        CONNECT: "CONNECT";
        MESSAGE: "MESSAGE";
        DISCONNECT: "DISCONNECT";
    }>>>;
    messageDirection: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    messageId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    routeKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    operationName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
/**
 * A zod schema for an API Gateway Proxy event
 *
 * @example
 * ```json
 * {
 *   "type": "REQUEST",
 *   "methodArn": "arn:aws:execute-api:us-east-1:123456789012:abcdef123/test/GET/request",
 *   "resource": "/request",
 *   "path": "/request",
 *   "httpMethod": "GET",
 *   "headers": {
 *     "X-AMZ-Date": "20170718T062915Z",
 *     "Accept": "application/json",
 *     "HeaderAuth1": "headerValue1"
 *   },
 *   "queryStringParameters": {
 *     "QueryString1": "queryValue1"
 *   },
 *   "pathParameters": {},
 *   "stageVariables": null,
 *   "requestContext": {
 *     "path": "/request",
 *     "accountId": "123456789012",
 *     "resourceId": "05c7jb",
 *     "stage": "test",
 *     "requestId": "...",
 *     "identity": {
 *       "cognitoIdentityPoolId": null,
 *       "accountId": null,
 *       "cognitoIdentityId": null,
 *       "caller": null,
 *       "sourceIp": "192.168.1.1",
 *       "principalOrgId": null,
 *       "accessKey": null,
 *       "cognitoAuthenticationType": null,
 *       "cognitoAuthenticationProvider": null,
 *       "userArn": null,
 *       "userAgent": "HTTPie/3.2.2",
 *       "user": null
 *     }
 *   },
 *   "resourcePath": "/request",
 *   "httpMethod": "GET",
 *   "apiId": "abcdef123"
 * }
 * ```
 * @see {@link APIGatewayProxyEvent | `APIGatewayProxyEvent`}
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/set-up-lambda-proxy-integrations.html}
 */
declare const APIGatewayProxyEventSchema: z.ZodObject<{
    resource: z.ZodString;
    path: z.ZodString;
    httpMethod: z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        HEAD: "HEAD";
        OPTIONS: "OPTIONS";
    }>;
    headers: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    multiValueHeaders: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>>;
    queryStringParameters: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>;
    multiValueQueryStringParameters: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    pathParameters: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    stageVariables: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>>;
    requestContext: z.ZodObject<{
        accountId: z.ZodString;
        apiId: z.ZodString;
        deploymentId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        authorizer: z.ZodOptional<z.ZodNullable<z.ZodUnion<readonly [z.ZodObject<{
            integrationLatency: z.ZodNumber;
            principalId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            claims: z.ZodRecord<z.ZodString, z.ZodAny>;
            scopes: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>]>>>;
        stage: z.ZodString;
        protocol: z.ZodString;
        identity: z.ZodObject<{
            accessKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            accountId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            apiKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            apiKeyId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            caller: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoAuthenticationProvider: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoAuthenticationType: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoIdentityId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoIdentityPoolId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sourceIp: z.ZodOptional<z.ZodUnion<readonly [z.ZodIPv4, z.ZodIPv6, z.ZodLiteral<"test-invoke-source-ip">]>>;
            user: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            userAgent: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            userArn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            clientCert: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                clientCertPem: z.ZodString;
                subjectDN: z.ZodString;
                issuerDN: z.ZodString;
                serialNumber: z.ZodString;
                validity: z.ZodObject<{
                    notBefore: z.ZodString;
                    notAfter: z.ZodString;
                }, z.core.$strip>;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        requestId: z.ZodString;
        requestTime: z.ZodString;
        requestTimeEpoch: z.ZodNumber;
        resourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        resourcePath: z.ZodString;
        domainName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        domainPrefix: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        extendedRequestId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        httpMethod: z.ZodEnum<{
            GET: "GET";
            POST: "POST";
            PUT: "PUT";
            PATCH: "PATCH";
            DELETE: "DELETE";
            HEAD: "HEAD";
            OPTIONS: "OPTIONS";
        }>;
        path: z.ZodString;
        connectedAt: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        connectionId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        eventType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            CONNECT: "CONNECT";
            MESSAGE: "MESSAGE";
            DISCONNECT: "DISCONNECT";
        }>>>;
        messageDirection: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        messageId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        routeKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        operationName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>;
    body: z.ZodNullable<z.ZodString>;
    isBase64Encoded: z.ZodBoolean;
}, z.core.$strip>;
/**
 * A zod schema for an API Gateway Request Authorizer event
 *
 * @example
 * ```json
 * {
 *   "type": "REQUEST",
 *   "methodArn": "arn:aws:execute-api:us-west-2:123456789012:ymy8tbxw7b/prod/GET/",
 *   "resource": "/{proxy+}",
 *   "path": "/hello/world",
 *   "httpMethod": "GET",
 *   "headers": {
 *     "X-AMZ-Date": "20170718T062915Z",
 *     "Accept": "application/json",
 *     "HeaderAuth1": "headerValue1"
 *   },
 *   "multiValueHeaders": {
 *     "X-AMZ-Date": ["20170718T062915Z"],
 *     "Accept": ["application/json"],
 *     "HeaderAuth1": ["headerValue1"]
 *   },
 *   "queryStringParameters": {},
 *   "multiValueQueryStringParameters": {},
 *   "pathParameters": {},
 *   "stageVariables": {},
 *   "requestContext": {
 *     "path": "/request",
 *     "accountId": "123456789012",
 *     "resourceId": "05c7jb",
 *     "stage": "test",
 *     "requestId": "...",
 *     "identity": {
 *       "cognitoIdentityPoolId": null,
 *       "accountId": null,
 *       "cognitoIdentityId": null,
 *       "caller": null,
 *       "sourceIp": "192.168.1.1",
 *       "principalOrgId": null,
 *       "accessKey": null,
 *       "cognitoAuthenticationType": null,
 *       "cognitoAuthenticationProvider": null,
 *       "userArn": null,
 *       "userAgent": "HTTPie/3.2.2",
 *       "user": null
 *     }
 *   },
 *   "domainName": "id.execute-api.us-west-2.amazonaws.com",
 *   "deploymentId": "lle82z",
 *   "apiId": "ymy8tbxw7b"
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-lambda-authorizer-input.html#w76aac15b9c21c25c21b5}
 */
declare const APIGatewayRequestAuthorizerEventSchema: z.ZodObject<{
    type: z.ZodLiteral<"REQUEST">;
    methodArn: z.ZodString;
    resource: z.ZodString;
    path: z.ZodString;
    httpMethod: z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        HEAD: "HEAD";
        OPTIONS: "OPTIONS";
    }>;
    headers: z.ZodRecord<z.ZodString, z.ZodString>;
    multiValueHeaders: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
    queryStringParameters: z.ZodRecord<z.ZodString, z.ZodString>;
    multiValueQueryStringParameters: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
    pathParameters: z.ZodRecord<z.ZodString, z.ZodString>;
    stageVariables: z.ZodRecord<z.ZodString, z.ZodString>;
    requestContext: z.ZodObject<{
        accountId: z.ZodString;
        apiId: z.ZodString;
        deploymentId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        authorizer: z.ZodOptional<z.ZodNullable<z.ZodUnion<readonly [z.ZodObject<{
            integrationLatency: z.ZodNumber;
            principalId: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            claims: z.ZodRecord<z.ZodString, z.ZodAny>;
            scopes: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>]>>>;
        stage: z.ZodString;
        protocol: z.ZodString;
        identity: z.ZodObject<{
            accessKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            accountId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            apiKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            apiKeyId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            caller: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoAuthenticationProvider: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoAuthenticationType: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoIdentityId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            cognitoIdentityPoolId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            principalOrgId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sourceIp: z.ZodOptional<z.ZodUnion<readonly [z.ZodIPv4, z.ZodIPv6, z.ZodLiteral<"test-invoke-source-ip">]>>;
            user: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            userAgent: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            userArn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            clientCert: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                clientCertPem: z.ZodString;
                subjectDN: z.ZodString;
                issuerDN: z.ZodString;
                serialNumber: z.ZodString;
                validity: z.ZodObject<{
                    notBefore: z.ZodString;
                    notAfter: z.ZodString;
                }, z.core.$strip>;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        requestId: z.ZodString;
        requestTime: z.ZodString;
        requestTimeEpoch: z.ZodNumber;
        resourceId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        resourcePath: z.ZodString;
        domainName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        domainPrefix: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        extendedRequestId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        httpMethod: z.ZodEnum<{
            GET: "GET";
            POST: "POST";
            PUT: "PUT";
            PATCH: "PATCH";
            DELETE: "DELETE";
            HEAD: "HEAD";
            OPTIONS: "OPTIONS";
        }>;
        path: z.ZodString;
        connectedAt: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        connectionId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        eventType: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            CONNECT: "CONNECT";
            MESSAGE: "MESSAGE";
            DISCONNECT: "DISCONNECT";
        }>>>;
        messageDirection: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        messageId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        routeKey: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        operationName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>;
    domainName: z.ZodOptional<z.ZodString>;
    deploymentId: z.ZodOptional<z.ZodString>;
    apiId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/**
 * A zod schema for an API Gateway Token Authorizer event
 *
 * @example
 * ```json
 * {
 *   "type": "TOKEN",
 *   "authorizationToken": "Bearer abcd1234",
 *   "methodArn": "arn:aws:execute-api:us-west-2:123456789012:ymy8tbxw7b/prod/GET/"
 * }
 * ```
 *
 * @see {@link https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-lambda-authorizer-input.html#w76aac15b9c21c25c21b3}
 */
declare const APIGatewayTokenAuthorizerEventSchema: z.ZodObject<{
    type: z.ZodLiteral<"TOKEN">;
    authorizationToken: z.ZodString;
    methodArn: z.ZodString;
}, z.core.$strip>;
export { APIGatewayProxyEventSchema, APIGatewayRequestAuthorizerEventSchema, APIGatewayTokenAuthorizerEventSchema, APIGatewayEventRequestContextSchema, };
//# sourceMappingURL=api-gateway.d.ts.map