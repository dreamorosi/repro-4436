import { z } from 'zod';
/**
 * Zod schema for a SES record from an SES event.
 */
declare const SesRecordSchema: z.ZodObject<{
    eventSource: z.ZodLiteral<"aws:ses">;
    eventVersion: z.ZodString;
    ses: z.ZodObject<{
        mail: z.ZodObject<{
            timestamp: z.ZodISODateTime;
            source: z.ZodString;
            messageId: z.ZodString;
            destination: z.ZodArray<z.ZodString>;
            headersTruncated: z.ZodBoolean;
            headers: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>;
            commonHeaders: z.ZodObject<{
                from: z.ZodArray<z.ZodString>;
                to: z.ZodArray<z.ZodString>;
                cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
                bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
                sender: z.ZodOptional<z.ZodArray<z.ZodString>>;
                'reply-to': z.ZodOptional<z.ZodArray<z.ZodString>>;
                returnPath: z.ZodString;
                messageId: z.ZodString;
                date: z.ZodString;
                subject: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>;
        receipt: z.ZodObject<{
            timestamp: z.ZodISODateTime;
            processingTimeMillis: z.ZodNumber;
            recipients: z.ZodArray<z.ZodString>;
            spamVerdict: z.ZodObject<{
                status: z.ZodEnum<{
                    PASS: "PASS";
                    FAIL: "FAIL";
                    GRAY: "GRAY";
                    PROCESSING_FAILED: "PROCESSING_FAILED";
                }>;
            }, z.core.$strip>;
            virusVerdict: z.ZodObject<{
                status: z.ZodEnum<{
                    PASS: "PASS";
                    FAIL: "FAIL";
                    GRAY: "GRAY";
                    PROCESSING_FAILED: "PROCESSING_FAILED";
                }>;
            }, z.core.$strip>;
            spfVerdict: z.ZodObject<{
                status: z.ZodEnum<{
                    PASS: "PASS";
                    FAIL: "FAIL";
                    GRAY: "GRAY";
                    PROCESSING_FAILED: "PROCESSING_FAILED";
                }>;
            }, z.core.$strip>;
            dmarcVerdict: z.ZodObject<{
                status: z.ZodEnum<{
                    PASS: "PASS";
                    FAIL: "FAIL";
                    GRAY: "GRAY";
                    PROCESSING_FAILED: "PROCESSING_FAILED";
                }>;
            }, z.core.$strip>;
            dkimVerdict: z.ZodObject<{
                status: z.ZodEnum<{
                    PASS: "PASS";
                    FAIL: "FAIL";
                    GRAY: "GRAY";
                    PROCESSING_FAILED: "PROCESSING_FAILED";
                }>;
            }, z.core.$strip>;
            dmarcPolicy: z.ZodEnum<{
                none: "none";
                quarantine: "quarantine";
                reject: "reject";
            }>;
            action: z.ZodObject<{
                type: z.ZodEnum<{
                    Lambda: "Lambda";
                }>;
                invocationType: z.ZodLiteral<"Event">;
                functionArn: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>;
    }, z.core.$strip>;
}, z.core.$strip>;
/**
 * Zod schema for SES events from AWS.
 *
 * @example
 * ```json
 * {
 *   "Records": [
 *     {
 *       "eventVersion": "1.0",
 *       "ses": {
 *         "mail": {
 *           "commonHeaders": {
 *             "from": [
 *               "Jane Doe <janedoe@example.com>"
 *             ],
 *             "to": [
 *               "johndoe@example.com"
 *             ],
 *             "returnPath": "janedoe@example.com",
 *             "messageId": "<0123456789example.com>",
 *             "date": "Wed, 7 Oct 2015 12:34:56 -0700",
 *             "subject": "Test Subject"
 *           },
 *           "source": "janedoe@example.com",
 *           "timestamp": "1970-01-01T00:00:00.000Z",
 *           "destination": [
 *             "johndoe@example.com"
 *           ],
 *           "headers": [
 *             {
 *               "name": "Return-Path",
 *               "value": "<janedoe@example.com>"
 *             },
 *             {
 *               "name": "Received",
 *               "value": "from mailer.example.com (mailer.example.com [203.0.113.1]) by ..."
 *             },
 *             {
 *               "name": "DKIM-Signature",
 *               "value": "v=1; a=rsa-sha256; c=relaxed/relaxed; d=example.com; s=example; ..."
 *             },
 *             {
 *               "name": "MIME-Version",
 *               "value": "1.0"
 *             },
 *             {
 *               "name": "From",
 *               "value": "Jane Doe <janedoe@example.com>"
 *             },
 *             {
 *               "name": "Date",
 *               "value": "Wed, 7 Oct 2015 12:34:56 -0700"
 *             },
 *             {
 *               "name": "Message-ID",
 *               "value": "<0123456789example.com>"
 *             },
 *             {
 *               "name": "Subject",
 *               "value": "Test Subject"
 *             },
 *             {
 *               "name": "To",
 *               "value": "johndoe@example.com"
 *             },
 *             {
 *               "name": "Content-Type",
 *               "value": "text/plain; charset=UTF-8"
 *             }
 *           ],
 *           "headersTruncated": false,
 *           "messageId": "o3vrnil0e2ic28tr"
 *         },
 *         "receipt": {
 *           "recipients": [
 *             "johndoe@example.com"
 *           ],
 *           "timestamp": "1970-01-01T00:00:00.000Z",
 *           "spamVerdict": {
 *             "status": "PASS"
 *           },
 *           "dkimVerdict": {
 *             "status": "PASS"
 *           },
 *           "dmarcPolicy": "reject",
 *           "processingTimeMillis": 574,
 *           "action": {
 *             "type": "Lambda",
 *             "invocationType": "Event",
 *             "functionArn": "arn:aws:lambda:us-west-2:012345678912:function:Example"
 *           },
 *           "dmarcVerdict": {
 *             "status": "PASS"
 *           },
 *           "spfVerdict": {
 *             "status": "PASS"
 *           },
 *           "virusVerdict": {
 *             "status": "PASS"
 *           }
 *         }
 *       },
 *       "eventSource": "aws:ses"
 *     }
 *   ]
 * }
 * ```
 *
 * @see {@link SesEvent | SesEvent}
 * @see {@link https://docs.aws.amazon.com/ses/latest/dg/receiving-email-notifications-examples.html}
 */
declare const SesSchema: z.ZodObject<{
    Records: z.ZodArray<z.ZodObject<{
        eventSource: z.ZodLiteral<"aws:ses">;
        eventVersion: z.ZodString;
        ses: z.ZodObject<{
            mail: z.ZodObject<{
                timestamp: z.ZodISODateTime;
                source: z.ZodString;
                messageId: z.ZodString;
                destination: z.ZodArray<z.ZodString>;
                headersTruncated: z.ZodBoolean;
                headers: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    value: z.ZodString;
                }, z.core.$strip>>;
                commonHeaders: z.ZodObject<{
                    from: z.ZodArray<z.ZodString>;
                    to: z.ZodArray<z.ZodString>;
                    cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    sender: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    'reply-to': z.ZodOptional<z.ZodArray<z.ZodString>>;
                    returnPath: z.ZodString;
                    messageId: z.ZodString;
                    date: z.ZodString;
                    subject: z.ZodString;
                }, z.core.$strip>;
            }, z.core.$strip>;
            receipt: z.ZodObject<{
                timestamp: z.ZodISODateTime;
                processingTimeMillis: z.ZodNumber;
                recipients: z.ZodArray<z.ZodString>;
                spamVerdict: z.ZodObject<{
                    status: z.ZodEnum<{
                        PASS: "PASS";
                        FAIL: "FAIL";
                        GRAY: "GRAY";
                        PROCESSING_FAILED: "PROCESSING_FAILED";
                    }>;
                }, z.core.$strip>;
                virusVerdict: z.ZodObject<{
                    status: z.ZodEnum<{
                        PASS: "PASS";
                        FAIL: "FAIL";
                        GRAY: "GRAY";
                        PROCESSING_FAILED: "PROCESSING_FAILED";
                    }>;
                }, z.core.$strip>;
                spfVerdict: z.ZodObject<{
                    status: z.ZodEnum<{
                        PASS: "PASS";
                        FAIL: "FAIL";
                        GRAY: "GRAY";
                        PROCESSING_FAILED: "PROCESSING_FAILED";
                    }>;
                }, z.core.$strip>;
                dmarcVerdict: z.ZodObject<{
                    status: z.ZodEnum<{
                        PASS: "PASS";
                        FAIL: "FAIL";
                        GRAY: "GRAY";
                        PROCESSING_FAILED: "PROCESSING_FAILED";
                    }>;
                }, z.core.$strip>;
                dkimVerdict: z.ZodObject<{
                    status: z.ZodEnum<{
                        PASS: "PASS";
                        FAIL: "FAIL";
                        GRAY: "GRAY";
                        PROCESSING_FAILED: "PROCESSING_FAILED";
                    }>;
                }, z.core.$strip>;
                dmarcPolicy: z.ZodEnum<{
                    none: "none";
                    quarantine: "quarantine";
                    reject: "reject";
                }>;
                action: z.ZodObject<{
                    type: z.ZodEnum<{
                        Lambda: "Lambda";
                    }>;
                    invocationType: z.ZodLiteral<"Event">;
                    functionArn: z.ZodString;
                }, z.core.$strip>;
            }, z.core.$strip>;
        }, z.core.$strip>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export { SesSchema, SesRecordSchema };
//# sourceMappingURL=ses.d.ts.map